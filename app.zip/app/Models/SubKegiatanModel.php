<?php

namespace App\Models;

use CodeIgniter\Model;

class SubKegiatanModel extends Model
{
    protected $table            = 'subkegiatan';
    protected $allowedFields    = [
        'nama_subkegiatan',
        'id_urusan',
        'id_indikator_kinerja_urusan',
        'id_kegiatan',
        'id_program',
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // ambil semua data table subkegiatan dengan join table urusan, indikator kinerja urusan, kegiatan, dan program
    public function getSubkegiatan()
    {
        // Query builder untuk mengambil data subkegiatan beserta data urusan, indikator kinerja terkait, kegiatan terkait, dan program terkait.
        $query = $this->db->table('subkegiatan')
            ->select('subkegiatan.id, subkegiatan.nama_subkegiatan, urusan.nama_urusan, indikator_kinerja_urusan.nama_indikator_kinerja, kegiatan.nama_kegiatan, program.nama_program')
            ->join('urusan', 'urusan.id = subkegiatan.id_urusan')
            ->join('indikator_kinerja_urusan', 'indikator_kinerja_urusan.id = subkegiatan.id_indikator_kinerja_urusan')
            ->join('kegiatan', 'kegiatan.id = subkegiatan.id_kegiatan')
            ->join('program', 'program.id = subkegiatan.id_program')
            ->get();

        return $query->getResultArray();
    }

    // Tambahkan metode berikut untuk mengambil data Indikator Kinerja Urusan berdasarkan Urusan yang dipilih
    public function getIndikatorKinerjaByUrusan($id_urusan)
    {
        return $this->db->table('indikator_kinerja_urusan')
            ->where('id_urusan', $id_urusan)
            ->get()
            ->getResultArray();
    }

    public function getProgramByIndikator($id_indikator_kinerja_urusan) 
    {
        return $this->db->table('program')
            ->where('id_indikator_kinerja_urusan', $id_indikator_kinerja_urusan)
            ->get()
            ->getResultArray();
    }

    public function getKegiatanByProgram($id_program)
    {
        return $this->db->table('kegiatan')
            ->where('id_program', $id_program)
            ->get()
            ->getResultArray();
    }

}
