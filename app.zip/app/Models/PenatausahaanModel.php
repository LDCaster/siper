<?php

namespace App\Models;

use CodeIgniter\Model;

class PenatausahaanModel extends Model
{
    protected $table            = 'penatausahaan';
    protected $allowedFields    = [
        'id_anggaran',
        'status',
        'tanggal',
        'karyawan_1',
        'karyawan_2',
        'kinerja_utama',
        'indikator_kinerja',
        'target',
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function getPenatausahaan()
{
    return $this->select('penatausahaan.id, penatausahaan.status, penatausahaan.tanggal, penatausahaan.kinerja_utama, penatausahaan.indikator_kinerja, penatausahaan.target, karyawan_1.nama AS nama_karyawan_1, karyawan_2.nama AS nama_karyawan_2, anggaran.urusan, anggaran.program, anggaran.kegiatan, anggaran.sub_kegiatan ')
                ->join('anggaran', 'anggaran.id = penatausahaan.id_anggaran')
                ->join('karyawan AS karyawan_1', 'karyawan_1.id = penatausahaan.karyawan_1')
                ->join('karyawan AS karyawan_2', 'karyawan_2.id = penatausahaan.karyawan_2')
                ->findAll();
}


}
