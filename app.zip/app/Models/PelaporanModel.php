<?php

namespace App\Models;

use CodeIgniter\Model;

class PelaporanModel extends Model
{
    protected $table            = 'pelaporan';
    protected $allowedFields    = [
        'id_anggaran',
        'status',
        'realisasi_nominal',
        'realisasi_persen',
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function getPelaporan()
    {
        return $this->select('pelaporan.id, pelaporan.status, pelaporan.realisasi_nominal, pelaporan.realisasi_persen, anggaran.urusan, anggaran.program, anggaran.kegiatan, anggaran.sub_kegiatan, anggaran.id_perencanaan, perencanaan.id, perencanaan.id_satuan, satuan.id, satuan.nama_satuan')
                    ->join('anggaran', 'anggaran.id = pelaporan.id_anggaran')
                    ->join('perencanaan', 'perencanaan.id = anggaran.id_perencanaan')
                    ->join('satuan', 'satuan.id = perencanaan.id_satuan')
                    ->findAll();
    }
}
