<?php

namespace App\Models;

use CodeIgniter\Model;

class Bab1lakipModel extends Model
{
    protected $table            = 'bab1lakip';
    protected $allowedFields    = [
        'id_karyawan',
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function getBab1lakip()
{
    return $this->select('bab1lakip.id, bab1lakip.id_karyawan, karyawan.nama')
                ->join('karyawan', 'karyawan.id = bab1lakip.id_karyawan')
                ->findAll();
}


}
