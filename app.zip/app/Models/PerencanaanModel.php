<?php

namespace App\Models;

use CodeIgniter\Model;

class PerencanaanModel extends Model
{
    protected $table            = 'perencanaan';
    protected $allowedFields    = [
        'id_urusan',
        'id_indikator_kinerja_urusan',
        'id_program',
        'id_kegiatan',
        'id_subkegiatan',
        'id_indikator',
        'id_satuan',
        'pagu_indikatif',
        'target',
        'status_perencanaan',
        'status_tujuan',
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // ambil semua data table perencanaan dengan join table urusan, indikator_kinerja_urusan program, kegiatan, subkegiatan, indikator, dan satuan

    public function getPerencanaan()
    {
        // Query builder untuk mengambil data perencanaan beserta data urusan, indikator_kinerja_urusan program, kegiatan, subkegiatan, indikator, dan satuan terkait.
        $query = $this->db->table('perencanaan')
            ->select('perencanaan.id, urusan.nama_urusan, indikator_kinerja_urusan.nama_indikator_kinerja, program.nama_program, kegiatan.nama_kegiatan, subkegiatan.nama_subkegiatan, indikator.nama_indikator, satuan.nama_satuan, perencanaan.pagu_indikatif, perencanaan.target, perencanaan.status_perencanaan, perencanaan.status_tujuan')
            ->join('urusan', 'urusan.id = perencanaan.id_urusan')
            ->join('indikator_kinerja_urusan', 'indikator_kinerja_urusan.id = perencanaan.id_indikator_kinerja_urusan')
            ->join('program', 'program.id = perencanaan.id_program')
            ->join('kegiatan', 'kegiatan.id = perencanaan.id_kegiatan')
            ->join('subkegiatan', 'subkegiatan.id = perencanaan.id_subkegiatan')
            ->join('indikator', 'indikator.id = perencanaan.id_indikator')
            ->join('satuan', 'satuan.id = perencanaan.id_satuan')
            ->get();

        return $query->getResultArray();
    }
    public function getPerencanaanRakor()
    {
        // Query builder untuk mengambil data perencanaan beserta data urusan, indikator_kinerja_urusan program, kegiatan, subkegiatan, indikator, dan satuan terkait.
        $query = $this->db->table('perencanaan')
            ->select('perencanaan.id, urusan.nama_urusan, indikator_kinerja_urusan.nama_indikator_kinerja, program.nama_program, kegiatan.nama_kegiatan, subkegiatan.nama_subkegiatan, indikator.nama_indikator, satuan.nama_satuan, perencanaan.pagu_indikatif, perencanaan.target, perencanaan.status_perencanaan, perencanaan.status_tujuan')
            ->join('urusan', 'urusan.id = perencanaan.id_urusan')
            ->join('indikator_kinerja_urusan', 'indikator_kinerja_urusan.id = perencanaan.id_indikator_kinerja_urusan')
            ->join('program', 'program.id = perencanaan.id_program')
            ->join('kegiatan', 'kegiatan.id = perencanaan.id_kegiatan')
            ->join('subkegiatan', 'subkegiatan.id = perencanaan.id_subkegiatan')
            ->join('indikator', 'indikator.id = perencanaan.id_indikator')
            ->join('satuan', 'satuan.id = perencanaan.id_satuan')
            ->where('status_perencanaan', 'rakortekbang')
            ->get();

        return $query->getResultArray();
    }
    public function getPerencanaanRenja()
    {
        // Query builder untuk mengambil data perencanaan beserta data urusan, indikator_kinerja_urusan program, kegiatan, subkegiatan, indikator, dan satuan terkait.
        $query = $this->db->table('perencanaan')
            ->select('perencanaan.id, urusan.nama_urusan, indikator_kinerja_urusan.nama_indikator_kinerja, program.nama_program, kegiatan.nama_kegiatan, subkegiatan.nama_subkegiatan, indikator.nama_indikator, satuan.nama_satuan, perencanaan.pagu_indikatif, perencanaan.target, perencanaan.status_perencanaan, perencanaan.status_tujuan')
            ->join('urusan', 'urusan.id = perencanaan.id_urusan')
            ->join('indikator_kinerja_urusan', 'indikator_kinerja_urusan.id = perencanaan.id_indikator_kinerja_urusan')
            ->join('program', 'program.id = perencanaan.id_program')
            ->join('kegiatan', 'kegiatan.id = perencanaan.id_kegiatan')
            ->join('subkegiatan', 'subkegiatan.id = perencanaan.id_subkegiatan')
            ->join('indikator', 'indikator.id = perencanaan.id_indikator')
            ->join('satuan', 'satuan.id = perencanaan.id_satuan')
            ->where('status_perencanaan', 'renja')
            ->get();

        return $query->getResultArray();
    }
    
        // fungsi untuk mengambil daftar urusan
        public function getUrusan()
        {
            return $this->db->table('urusan')->get()->getResult();
        }

        // fungsi untuk mengambil daftar indikator kinerja urusan berdasarkan id_urusan
        public function getIndikatorKinerjaByUrusan($idUrusan)
        {
            return $this->db->table('indikator_kinerja_urusan')->where('id_urusan', $idUrusan)->get()->getResult();
        }

        // fungsi untuk mengambil daftar program berdasarkan id_indikator_kinerja_urusan
        public function getProgramByIndikatorKinerja($idIndikatorKinerja)
        {
            return $this->db->table('program')->where('id_indikator_kinerja_urusan', $idIndikatorKinerja)->get()->getResult();
        }

      // Fungsi untuk mengambil daftar kegiatan berdasarkan id_program
      public function getKegiatanByProgram($idProgram)
      {
          return $this->db->table('kegiatan')->where('id_program', $idProgram)->get()->getResult();
      }
  
      // Fungsi untuk mengambil daftar subkegiatan berdasarkan id_kegiatan
      public function getSubKegiatanByKegiatan($idKegiatan)
      {
          return $this->db->table('subkegiatan')->where('id_kegiatan', $idKegiatan)->get()->getResult();
      }

        // Fungsi untuk mengambil daftar indikator berdasarkan id_subkegiatan
        public function getIndikatorBySubKegiatan($idSubKegiatan)
        {
            return $this->db->table('indikator')->where('id_subkegiatan', $idSubKegiatan)->get()->getResult();
        }

        // Fungsi untuk mengambil daftar satuan berdasarkan id_indikator
        public function getSatuanByIndikator($idIndikator)
        {
            return $this->db->table('satuan')->where('id_indikator', $idIndikator)->get()->getResult();
        }
}
