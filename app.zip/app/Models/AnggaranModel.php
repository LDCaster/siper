<?php

namespace App\Models;

use CodeIgniter\Model;

class AnggaranModel extends Model
{
    protected $table            = 'anggaran';
    protected $allowedFields    = [
        'urusan',
        'program',
        'kegiatan',
        'sub_kegiatan',
        'sumber_pendanaan',
        'lokasi',
        'waktu_pelaksanaan',
        'kelompok_sasaran',
        'jumlah',
        'target',
        'id_perencanaan',
    ];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // ambil semua data table anggaran dengan join table urusan, indikator kinerja urusan, kegiatan, program, subkegiatan, dan indikator
    public function getAnggaranPerpustakaan()
    {
        // Query builder untuk mengambil data anggaran beserta data urusan, indikator kinerja terkait, kegiatan terkait, program terkait, subkegiatan terkait, dan indikator terkait.
        $query = $this->db->table('anggaran')
            ->select('anggaran.id, anggaran.urusan, anggaran.program, anggaran.kegiatan, anggaran.sub_kegiatan, anggaran.sumber_pendanaan, anggaran.lokasi, anggaran.waktu_pelaksanaan, anggaran.kelompok_sasaran, anggaran.jumlah, anggaran.target, perencanaan.status_tujuan')
            ->join('perencanaan', 'perencanaan.id = anggaran.id_perencanaan')
            ->where('status_tujuan', 'perpus')
            ->get();

        return $query->getResultArray();
    }

    // ambil semua data table perencanaan dengan join table urusan, program, kegiatan, subkegiatan dan hanya status_tujuan = perpus
    public function getPerencanaanPerpustakaan()
    {
        // Query builder untuk mengambil data perencanaan beserta data urusan, program, kegiatan, subkegiatan terkait.
        $query = $this->db->table('perencanaan')
            ->select('perencanaan.id, program.nama_program, kegiatan.nama_kegiatan, subkegiatan.nama_subkegiatan, perencanaan.status_tujuan')
            ->join('program', 'program.id = perencanaan.id_program')
            ->join('kegiatan', 'kegiatan.id = perencanaan.id_kegiatan')
            ->join('subkegiatan', 'subkegiatan.id = perencanaan.id_subkegiatan')
            ->where('status_tujuan', 'perpus')
            ->get();

        return $query->getResultArray();
    }

    public function getPerencanaanKearsipan()
    {
        // Query builder untuk mengambil data perencanaan beserta data urusan, program, kegiatan, subkegiatan terkait.
        $query = $this->db->table('perencanaan')
            ->select('perencanaan.id, program.nama_program, kegiatan.nama_kegiatan, subkegiatan.nama_subkegiatan, perencanaan.status_tujuan')
            ->join('program', 'program.id = perencanaan.id_program')
            ->join('kegiatan', 'kegiatan.id = perencanaan.id_kegiatan')
            ->join('subkegiatan', 'subkegiatan.id = perencanaan.id_subkegiatan')
            ->where('status_tujuan', 'arsip')
            ->get();

        return $query->getResultArray();
    }

    public function getAnggaranKearsipan()
    {
        // Query builder untuk mengambil data anggaran beserta data urusan, indikator kinerja terkait, kegiatan terkait, program terkait, subkegiatan terkait, dan indikator terkait.
        $query = $this->db->table('anggaran')
            ->select('anggaran.id, anggaran.urusan, anggaran.program, anggaran.kegiatan, anggaran.sub_kegiatan, anggaran.sumber_pendanaan, anggaran.lokasi, anggaran.waktu_pelaksanaan, anggaran.kelompok_sasaran, anggaran.jumlah, anggaran.target, perencanaan.status_tujuan')
            ->join('perencanaan', 'perencanaan.id = anggaran.id_perencanaan')
            ->where('status_tujuan', 'arsip')
            ->get();

        return $query->getResultArray();
    }
}
