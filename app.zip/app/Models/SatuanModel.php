<?php

namespace App\Models;

use CodeIgniter\Model;

class SatuanModel extends Model
{
    protected $table            = 'satuan';
    protected $allowedFields    = [
        'nama_satuan',
        'id_urusan',
        'id_indikator_kinerja_urusan',
        'id_kegiatan',
        'id_program',
        'id_subkegiatan',
        'id_indikator'  
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // ambil semua data table satuan dengan join table urusan, indikator kinerja urusan, kegiatan, program, subkegiatan, dan indikator
    public function getSatuan()
    {
        // Query builder untuk mengambil data satuan beserta data urusan, indikator kinerja terkait, kegiatan terkait, program terkait, subkegiatan terkait, dan indikator terkait.
        $query = $this->db->table('satuan')
            ->select('satuan.id, satuan.nama_satuan, urusan.nama_urusan, indikator_kinerja_urusan.nama_indikator_kinerja, kegiatan.nama_kegiatan, program.nama_program, subkegiatan.nama_subkegiatan, indikator.nama_indikator')
            ->join('urusan', 'urusan.id = satuan.id_urusan')
            ->join('indikator_kinerja_urusan', 'indikator_kinerja_urusan.id = satuan.id_indikator_kinerja_urusan')
            ->join('kegiatan', 'kegiatan.id = satuan.id_kegiatan')
            ->join('program', 'program.id = satuan.id_program')
            ->join('subkegiatan', 'subkegiatan.id = satuan.id_subkegiatan')
            ->join('indikator', 'indikator.id = satuan.id_indikator')
            ->get();

        return $query->getResultArray();
    }

     // Tambahkan metode berikut untuk mengambil data Indikator Kinerja Urusan berdasarkan Urusan yang dipilih
     public function getIndikatorKinerjaByUrusan($id_urusan)
     {
         return $this->db->table('indikator_kinerja_urusan')
             ->where('id_urusan', $id_urusan)
             ->get()
             ->getResultArray();
     }
 
     public function getProgramByIndikator($id_indikator_kinerja_urusan) 
     {
         return $this->db->table('program')
             ->where('id_indikator_kinerja_urusan', $id_indikator_kinerja_urusan)
             ->get()
             ->getResultArray();
     }
 
     public function getKegiatanByProgram($id_program)
     {
         return $this->db->table('kegiatan')
             ->where('id_program', $id_program)
             ->get()
             ->getResultArray();
     }

    public function getSubKegiatanByKegiatan($id_kegiatan)
    {
            return $this->db->table('subkegiatan')
                ->where('id_kegiatan', $id_kegiatan)
                ->get()
                ->getResultArray();
    }

    public function getIndikatorBySubKegiatan($id_subkegiatan)
    {
            return $this->db->table('indikator')
                ->where('id_subkegiatan', $id_subkegiatan)
                ->get()
                ->getResultArray();
    }

}
