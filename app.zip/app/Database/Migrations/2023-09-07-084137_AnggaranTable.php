<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AnggaranTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 5,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'urusan' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
           
            'program' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'kegiatan' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'sub_kegiatan' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            
            'sumber_pendanaan' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'lokasi' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'waktu_pelaksanaan' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'kelompok_sasaran' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'jumlah' => [
                'type' => 'DOUBLE',
            ],
            'target' => [
                'type' => 'DOUBLE',
            ],
            'id_perencanaan' => [
                'type' => 'INT',
                'constraint' => 5,
                'unsigned' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('anggaran');
    }

    public function down()
    {
        $this->forge->dropTable('anggaran');
    }
}
