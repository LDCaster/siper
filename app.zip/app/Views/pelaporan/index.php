<?= $this->extend('templates/main'); ?>

<?= $this->section('content'); ?>

<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Pelaporan</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="#">Modules</a></div>
                <div class="breadcrumb-item">DataTables</div>
            </div>
        </div>

        <div class="section-body">
            <h2 class="section-title">Data Pelaporan</h2>
            <p class="section-lead">
                Ini merupakan data Pelaporan yang terdaftar di Dispusip.
            </p>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>TABEL DATA PELAPORAN</h4>
                        </div>
                        <div class="card-body">
                            <div class="buttons" style="margin-top: -20px;">
                                <a href="/pelaporan/create" class="btn btn-primary">Tambah</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped" id="table-2">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Data Anggaran</th>
                                            <th>Realisasi Rp. </th>
                                            <th>Realisasi %</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; ?>
                                        <?php foreach ($pelaporans as $pelaporan) : ?>
                                       
                                            <tr>
                                                <td><?= $no++ ?></td>
                                                <td><?= $pelaporan['urusan']; ?> <br>
                                                <?= $pelaporan['program']; ?><br>
                                                <?= $pelaporan['kegiatan']; ?><br>
                                              <?= $pelaporan['sub_kegiatan']; ?>
                                            
                                            
                                            </td>
                                                <td><?= $pelaporan['realisasi_nominal']; ?></td>
                                                <td><?= $pelaporan['realisasi_persen']; ?></td>
                                                
                                                <td>
                                                    <a href="/pelaporan/preview/<?= $pelaporan['id']; ?>" class="btn btn-info btn-sm" >Pratinjau</a>
                                                    <a href="/pelaporan/download/<?= $pelaporan['id']; ?>" class="btn btn-success btn-sm">Unduh</a>
                                                    <a href="/pelaporan/destroy/<?= $pelaporan['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                                                </td>
                                            </tr>
                                        
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?= $this->endSection(); ?>

