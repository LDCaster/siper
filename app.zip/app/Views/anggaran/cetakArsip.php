<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak </title>
   
    <style>
        table {
        border-collapse: collapse;
        width: 100%;
        }

        table, th, td {
        border: 1px solid black;
        }

        th {
        padding: 10px;
        }

        td {
        padding: 10px;
        vertical-align: top;
        }

        td.label {
        width: 20%;
        }

        .heading-2 {
        text-align: center;
        padding-top: 10px;
        padding-bottom: 20px;
        }

        /* Gaya tambahan untuk sub-tabel */
        .sub-table {
        width: 100%;
        border-collapse: collapse;
        }

        .sub-table th, .sub-table td {
        border: 1px solid black;
        padding: 10px;
        vertical-align: top;
        }
    </style>
</head>
<body>

<table>
  <tr>
    <th colspan="2">Dokumen Pelaksanaan Anggaran Daerah <br> 
    Satuan Kerja Perangkar Kerja</th>
    <th rowspan="2">Formulir <br> DPA PERJANJIAN BELANJA <br> SKPD</th>
  </tr>
  <tr>
    <td class="heading-2" colspan="2">Kab. Tanah Laut <br> Tahun Anggaran </td>
  </tr>
  <tr>
    <td class="label">Bidang Urusan</td>
    <td colspan="3">:</td>
  </tr>
  <tr>
    <td class="label">Sasaran Program</td>
    <td colspan="2">:</td>
  </tr>
  <tr>
    <td  class="label">Capaian Program</td>
    <td colspan="2">
      <table class="sub-table">
        <tr>
          <th>Indikator</th>
          <th>Target</th>
        </tr>
        <tr>
          <td>Kegiatan 1</td>
          <td>Target 1</td>
        </tr>
        <tr>
          <td>Kegiatan 2</td>
          <td>Target 2</td>
        </tr>
        <!-- Tambahkan baris data lainnya sesuai kebutuhan -->
      </table>
    </td>
  </tr>
  <tr>
    <td class="label">Sasaran Program</td>
    <td colspan="2">:</td>
  </tr>
  <tr>
    <td colspan="3"></td>
  </tr>
   <tr>
    <th colspan="3">Indikator Dan Tolok Ukur Kinerja Kegiatan</th>
  </tr>
 	 <tr>
          <th>Indikator</th>
          <th>Tolok Ukur Kinerja</th>
          <th>Target Kinerja</th>
        </tr>
        <tr>
          <td>Kegiatan 1</td>
          <td>Target 1</td>
          <td>Target 1</td>
        </tr>
        <tr>
          <td>Kegiatan 2</td>
          <td>Target 2</td>
          <td>Target 1</td>
       </tr>
  <tr>
      <td class="label" colspan="3">Kelompok Sasaran Kegiatan : </td>
    </tr>
     <tr>
    <td colspan="3"></td>
    <tr>
    <td class="label">Sub Kegiatan</td>
    <td colspan="2">:</td>
  </tr>
  <tr>
    <td class="label">Sumber Pendanaan</td>
    <td colspan="2">:</td>
  </tr>
  <tr>
    <td class="label">Lokasi</td>
    <td colspan="2">:</td>
  </tr>
   <tr>
    <td  class="label">Keluaran Sub Kegiatan</td>
    <td colspan="2">
      <table class="sub-table">
        <tr>
          <th>Indikator</th>
          <th>Target</th>
        </tr>
        <tr>
          <td>Kegiatan 1</td>
          <td>Target 1</td>
        </tr>
        <tr>
          <td>Kegiatan 2</td>
          <td>Target 2</td>
        </tr>
        <!-- Tambahkan baris data lainnya sesuai kebutuhan -->
      </table>
    </td>
  </tr>
  <tr>
    <td class="label">Waktu Pelaksanaan</td>
    <td colspan="2">:</td>
  </tr>
  <tr>
    <td class="label">Keterangan</td>
    <td colspan="2">:</td>
  </tr>
</table>
</body>
</html>
