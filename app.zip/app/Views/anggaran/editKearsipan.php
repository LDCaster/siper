<?= $this->extend('templates/main'); ?>

<?= $this->section('content'); ?>

<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Form <?= $title; ?> Kearsipan</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="#"><?= $title; ?></a></div>
                <div class="breadcrumb-item">Edit</div>
            </div>
        </div>

        <div class="section-body">
            <h2 class="section-title">Form Edit <?= $title; ?> Kearsipan</h2>
            <p class="section-lead">
                Ini merupakan form untuk mengedit <?= $title; ?>.
            </p>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <!-- Form untuk mengedit anggaran Urusan -->
                        <form action="<?php echo base_url('anggaran/update/kearsipan/' . $anggaran['id']); ?>" method="post" enctype="multipart/form-data">

                            <?= csrf_field(); ?>
                            <div class="card-body">

                                <!-- Input untuk Perencanaan -->
                                <div class="form-group">
                                    <label>Perencanaan</label>
                                    <select class="form-control <?= (session('errors.id_perencanaan')) ? 'is-invalid' : ''; ?>" id="id_perencanaan" name="id_perencanaan">
                                        <option value="<?= $anggaran['id_perencanaan']; ?>"><?= $anggaran['id_perencanaan']; ?></option>
                                        <?php foreach ($perpustakaan as $perpus) : ?>
                                            <option value="<?= $perpus['id']; ?>"><?= $perpus['status_tujuan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Input untuk urusan -->
                                <div class="form-group">
                                    <label>Urusan</label>
                                    <input type="text" class="form-control <?= (session('errors.urusan')) ? 'is-invalid' : ''; ?>" id="urusan" name="urusan" value="<?= $anggaran['urusan']; ?>">
                                    <?php if (session('errors.urusan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.urusan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Input untuk program -->
                                <div class="form-group">
                                    <label>Program</label>
                                    <input type="text" class="form-control <?= (session('errors.program')) ? 'is-invalid' : ''; ?>" id="program" name="program" value="<?= $anggaran['program']; ?>">
                                    <?php if (session('errors.program')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.program'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Input untuk kegiatan -->
                                <div class="form-group">
                                    <label>Kegiatan</label>
                                    <input type="text" class="form-control <?= (session('errors.kegiatan')) ? 'is-invalid' : ''; ?>" id="kegiatan" name="kegiatan" value="<?= $anggaran['kegiatan']; ?>">
                                    <?php if (session('errors.kegiatan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.kegiatan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Input untuk Sub kegiatan -->
                                <div class="form-group">
                                    <label>Sub Kegiatan</label>
                                    <input type="text" class="form-control <?= (session('errors.sub_kegiatan')) ? 'is-invalid' : ''; ?>" id="sub_kegiatan" name="sub_kegiatan" value="<?= $anggaran['sub_kegiatan']; ?>">
                                    <?php if (session('errors.sub_kegiatan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.sub_kegiatan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Input untuk Sumber Pendanaan -->
                                <div class="form-group">
                                    <label>Sumber Pendanaan</label>
                                    <input type="text" class="form-control <?= (session('errors.sumber_pendanaan')) ? 'is-invalid' : ''; ?>" id="sumber_pendanaan" name="sumber_pendanaan" value="<?= $anggaran['sumber_pendanaan']; ?>">
                                    <?php if (session('errors.sumber_pendanaan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.sumber_pendanaan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Input untuk lokasi -->
                                <div class="form-group">
                                    <label>Lokasi</label>
                                    <input type="text" class="form-control <?= (session('errors.lokasi')) ? 'is-invalid' : ''; ?>" id="lokasi" name="lokasi" value="<?= $anggaran['lokasi']; ?>">
                                    <?php if (session('errors.lokasi')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.lokasi'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Input untuk Waktu Peleksanaan -->
                                <div class="form-group">
                                    <label>Waktu Peleksanaan</label>
                                    <input type="date" class="form-control <?= (session('errors.waktu_pelaksanaan')) ? 'is-invalid' : ''; ?>" id="waktu_pelaksanaan" name="waktu_pelaksanaan" value="<?= $anggaran['waktu_pelaksanaan']; ?>">
                                    <?php if (session('errors.waktu_pelaksanaan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.waktu_pelaksanaan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Input untuk Kelompok Sasaran -->
                                <div class="form-group">
                                    <label>Kelompok Sasaran</label>
                                    <input type="text" class="form-control <?= (session('errors.kelompok_sasaran')) ? 'is-invalid' : ''; ?>" id="kelompok_sasaran" name="kelompok_sasaran" value="<?= $anggaran['kelompok_sasaran']; ?>">
                                    <?php if (session('errors.kelompok_sasaran')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.kelompok_sasaran'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Input untuk jumlah -->
                                <div class="form-group">
                                    <label>Jumlah</label>
                                    <input type="number" class="form-control <?= (session('errors.jumlah')) ? 'is-invalid' : ''; ?>" id="jumlah" name="jumlah" value="<?= $anggaran['jumlah']; ?>">
                                    <?php if (session('errors.jumlah')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.jumlah'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Input untuk Perencanaan -->
                                <!-- <div class="form-group">
                                    <label>Perencanaan</label>
                                    <input type="text" class="form-control <?= (session('errors.id_perencanaan')) ? 'is-invalid' : ''; ?>" id="id_perencanaan" name="id_perencanaan" value="<?= $anggaran['id_perencanaan']; ?>">
                                    <?php if (session('errors.id_perencanaan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.id_perencanaan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div> -->

                                <!-- Tombol Submit dan Batal -->
                                <div class="card-footer text-right">
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                    <a href="<?= base_url('anggaran/index/kearsipan'); ?>" class="btn btn-secondary">Batal</a>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?= $this->endSection(); ?>