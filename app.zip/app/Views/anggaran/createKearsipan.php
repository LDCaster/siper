<?= $this->extend('templates/main'); ?>

<?= $this->section('content'); ?>

<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Form <?= $title; ?> Kearsipan</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="#"><?= $title; ?></a></div>
                <div class="breadcrumb-item">Create</div>
            </div>
        </div>

        <div class="section-body">
            <h2 class="section-title">Form <?= $title; ?> Kearsipan</h2>
            <p class="section-lead">
                Silakan isi formulir di bawah ini.
            </p>

            <!-- Form untuk menambahkan Indikator Kinerja Urusan -->
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Form <?= $title; ?> Kearsipan</h4>
                        </div>
                        <div class="card-body">
                            <!-- Form untuk membuat Indikator Kinerja Urusan -->
                            <form action="<?php echo base_url('anggaran/store/kearsipan'); ?>" method="post">
                                <?= csrf_field(); ?>

                                <!-- Input untuk Perencanaan -->
                                <div class="form-group">
                                    <label>Perencanaan</label>
                                    <select class="form-control <?= (session('errors.id_perencanaan')) ? 'is-invalid' : ''; ?>" id="id_perencanaan" name="id_perencanaan">
                                        <option value="">-- Pilih Perencanaan --</option>
                                        <?php foreach ($perpustakaan as $perpus) : ?>
                                            <option value="<?= $perpus['id']; ?>"><?= $perpus['status_tujuan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Input untuk urusan -->
                                <div class="form-group">
                                    <label>Urusan</label>
                                    <select class="form-control <?= (session('errors.urusan')) ? 'is-invalid' : ''; ?>" id="urusan" name="urusan">
                                        <option value="">-- Urusan --</option>
                                        <?php foreach ($urusan as $perpus) : ?>
                                            <option value="<?= $perpus['nama_urusan']; ?>"><?= $perpus['nama_urusan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Input untuk program     -->
                                <div class="form-group">
                                    <label>Program</label>
                                    <select type="text" class="form-control <?= (session('errors.program')) ? 'is-invalid' : ''; ?>" id="program" name="program">
                                        <option value="">-- Pilih Program --</option>
                                        <?php foreach ($perpustakaan as $perpus) : ?>
                                            <option value="<?= $perpus['nama_program']; ?>"><?= $perpus['nama_program']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Input untuk kegiatan -->
                                <div class="form-group">
                                    <label>Kegiatan</label>
                                    <select class="form-control <?= (session('errors.kegiatan')) ? 'is-invalid' : ''; ?>" id="kegiatan" name="kegiatan">
                                        <option value="">-- Pilih Kegiatan--</option>
                                        <?php foreach ($perpustakaan as $perpus) : ?>
                                            <option value="<?= $perpus['nama_kegiatan']; ?>"><?= $perpus['nama_kegiatan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Input untuk sub kegiatan -->
                                <div class="form-group">
                                    <label>Sub Kegiatan</label>
                                    <select class="form-control <?= (session('errors.sub_kegiatan')) ? 'is-invalid' : ''; ?>" id="sub_kegiatan" name="sub_kegiatan">
                                        <option value="">-- Pilih Sub Kegiatan --</option>
                                        <?php foreach ($perpustakaan as $perpus) : ?>
                                            <option value="<?= $perpus['nama_subkegiatan']; ?>"><?= $perpus['nama_subkegiatan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>

                                </div>

                                <!-- Input untuk sumber pendanaan -->
                                <div class="form-group">
                                    <label>Sumber Pendanaan</label>
                                    <input type="text" class="form-control <?= (session('errors.sumber_pendanaan')) ? 'is-invalid' : ''; ?>" id="sumber_pendanaan" name="sumber_pendanaan" placeholder="Tambahkan Sumber Pedanaan" value="<?= old('sumber_pendanaan'); ?>">
                                    <?php if (session('errors.sumber_pendanaan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.sumber_pendanaan'); ?>
                                        </div>
                                    <?php endif; ?>

                                </div>

                                <!-- Input untuk Lokasi -->
                                <div class="form-group">
                                    <label>Lokasi</label>
                                    <input type="text" class="form-control <?= (session('errors.lokasi')) ? 'is-invalid' : ''; ?>" id="lokasi" name="lokasi" placeholder="Tambahkan lokasi" value="<?= old('lokasi'); ?>">
                                    <?php if (session('errors.lokasi')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.lokasi'); ?>
                                        </div>
                                    <?php endif; ?>

                                </div>

                                <!-- Input untuk Waktu Pelaksanakan -->
                                <div class="form-group">
                                    <label>Waktu Pelaksanakan</label>
                                    <input type="date" class="form-control <?= (session('errors.waktu_pelaksanaan')) ? 'is-invalid' : ''; ?>" id="waktu_pelaksanaan" name="waktu_pelaksanaan" placeholder="Tambahkan waktu_pelaksanaan" value="<?= old('waktu_pelaksanaan'); ?>">
                                    <?php if (session('errors.waktu_pelaksanaan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.waktu_pelaksanaan'); ?>
                                        </div>
                                    <?php endif; ?>

                                </div>

                                <!-- Input untuk Kelompok Sasaran -->
                                <div class="form-group">
                                    <label>Kelompok Sasaran</label>
                                    <input type="text" class="form-control <?= (session('errors.kelompok_sasaran')) ? 'is-invalid' : ''; ?>" id="kelompok_sasaran" name="kelompok_sasaran" placeholder="Tambahkan Kelompok Sasaran" value="<?= old('kelompok_sasaran'); ?>">
                                    <?php if (session('errors.kelompok_sasaran')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.kelompok_sasaran'); ?>
                                        </div>
                                    <?php endif; ?>

                                </div>

                                <!-- Input untuk Jumlah -->
                                <div class="form-group">
                                    <label>Jumlah</label>
                                    <input type="number" class="form-control <?= (session('errors.jumlah')) ? 'is-invalid' : ''; ?>" id="jumlah" name="jumlah" placeholder="Tambahkan jumlah" value="<?= old('jumlah'); ?>">
                                    <?php if (session('errors.jumlah')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.jumlah'); ?>
                                        </div>
                                    <?php endif; ?>

                                </div>

                                <!-- Input untuk target -->
                                <div class="form-group">
                                    <label>Target</label>
                                    <input type="number" class="form-control <?= (session('errors.target')) ? 'is-invalid' : ''; ?>" id="target" name="target" placeholder="Tambahkan target" value="<?= old('target'); ?>">
                                    <?php if (session('errors.target')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.target'); ?>
                                        </div>
                                    <?php endif; ?>

                                </div>

                                <!-- Tombol Submit -->
                                <div class="card-footer text-right">
                                    <button class="btn btn-primary">Tambah</button>
                                    <a href="<?= base_url('/anggaran/index/kearsipan'); ?>" class="btn btn-secondary">Batal</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Form untuk menambahkan Indikator Kinerja Urusan -->
        </div>
    </section>
</div>

<?= $this->endSection(); ?>