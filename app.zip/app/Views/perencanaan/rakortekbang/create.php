<!-- resources/views/perencanaan/rakortekbang/create.php -->

<?= $this->extend('templates/main'); ?>

<?= $this->section('content'); ?>
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Form RAKORTEKBANG</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="#">Perencanaan</a></div>
                <div class="breadcrumb-item"><a href="#">RAKORTEKBANG</a></div>
                <div class="breadcrumb-item">Create</div>
            </div>
        </div>

        <div class="section-body">
            <h2 class="section-title">Form RAKORTEKBANG</h2>
            <p class="section-lead">
                Silakan isi formulir di bawah ini untuk membuat RAKORTEKBANG.
            </p>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Form RAKORTEKBANG</h4>
                        </div>
<div class="card-body">
                            <!-- Menampilkan pesan kesalahan jika ada -->
                            <?php if (session()->has('errors')): ?>
                                <div class=                        "alert alert-danger">
                                    <ul>
                                        <?php foreach (session('errors') as $error): ?>
                                            <li><?= esc($error) ?></li>
                                        <?php endforeach ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <form action="<?= route_to('perencanaan/store'); ?>" method="post">
                                <?= csrf_field(); ?>

                                <!-- Dropdown untuk memilih Urusan -->
                                <div class="form-group">
                                    <label>Urusan</label>
                                    <select class="form-control" id="id_urusan" name="id_urusan">
                                        <option value="">-- Pilih Urusan --</option>
                                        <?php foreach ($urusan as $urusanItem) : ?>
                                            <option value="<?= $urusanItem['id']; ?>"><?= $urusanItem['nama_urusan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Dropdown untuk memilih Indikator Kinerja Urusan -->
                                <div class="form-group">
                                    <label>Indikator Kinerja Urusan</label>
                                    <select class="form-control" id="id_indikator_kinerja_urusan" name="id_indikator_kinerja_urusan">
                                        <option value="">-- Pilih Indikator Kinerja Urusan --</option>
                                    </select>
                                </div>

                                <!-- Dropdown untuk memilih Program -->
                                <div class="form-group">
                                    <label>Program</label>
                                    <select class="form-control" id="id_program" name="id_program">
                                        <option value="">-- Pilih Program --</option>
                                    </select>
                                </div>
                                <!-- Dropdown untuk memilih Kegiatan -->
                                <div class="form-group">
                                    <label>Kegiatan</label>
                                    <select class="form-control" id="id_kegiatan" name="id_kegiatan">
                                        <option value="">-- Pilih Kegiatan --</option>
                                    </select>
                                </div>

                                <!-- Dropdown untuk memilih Sub Kegiatan -->
                                <div class="form-group">
                                    <label>Sub Kegiatan</label>
                                    <select class="form-control" id="id_subkegiatan" name="id_subkegiatan">
                                        <option value="">-- Pilih Sub Kegiatan --</option>
                                    </select>
                                </div>

                                <!-- Dropdown untuk memilih Indikator -->
                                <div class="form-group">
                                    <label>Indikator</label>
                                    <select class="form-control" id="id_indikator" name="id_indikator">
                                        <option value="">-- Pilih Indikator --</option>
                                    </select>
                                </div>

                                <!-- Dropdown untuk memilih Satuan -->
                                <div class="form-group">
                                    <label>Satuan</label>
                                    <select class="form-control" id="id_satuan" name="id_satuan">
                                        <option value="">-- Pilih Satuan --</option>
                                    </select>
                                </div>

                                <!-- Input Pagu Indikatif -->
                                <div class="form-group">
                                    <label for="pagu_indikatif">Pagu Indikatif</label>
                                    <input type="text" class="form-control" id="pagu_indikatif" name="pagu_indikatif" placeholder="Masukkan pagu indikatif">
                                </div>

                                <!-- Input Target -->
                                <div class="form-group">
                                    <label for="target">Target</label>
                                    <input type="text" class="form-control" id="target" name="target" placeholder="Masukkan target">
                                </div>

                                <!-- pilihan Status Perencanaan default value nya rakortekbang dan readonly -->
                                <div class="form-group">
                                    <label>Status Perencanaan</label>
                                    <select class="form-control" id="status_perencanaan" name="status_perencanaan" readonly>
                                        <option value="rakortekbang" selected>RAKORTEKBANG</option>
                                    </select>
                                </div>

                                <!-- pilihan Status Tujuan -->
                                <div class="form-group">
                                    <label>Status Tujuan</label>
                                    <select class="form-control" id="status_tujuan" name="status_tujuan">
                                        <option value="">-- Pilih Status Tujuan --</option>
                                        <option value="arsip">ARSIP</option>
                                        <option value="perpus">PERPUSTAKAAN</option>
                                    </select>
                                </div>

                                <!-- Tombol Submit -->
                                <div class="card-footer text-right">
                                    <button class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    $(document).ready(function() {
        // Mencegah klik pada elemen select
        $('#status_perencanaan').on('click', function(e) {
            e.preventDefault();
        });
    });
</script>
<!-- JavaScript untuk Dropdown Berantai -->
<script>
    $(document).ready(function() {

        $('#id_urusan').change(function() {
            var urusanID = $(this).val();
            if (urusanID != '') {
                $.ajax({
                    url: '/perencanaan/getIndikatorKinerjaByUrusan/' + urusanID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_indikator_kinerja_urusan').html('<option value="">-- Pilih Indikator Kinerja Urusan --</option>');
                        $.each(data, function(key, value) {
                            $('#id_indikator_kinerja_urusan').append('<option value="' + value.id + '">' + value.nama_indikator_kinerja + '</option>');
                        });
                    }
                });
            } else {
                $('#id_indikator_kinerja_urusan').html('<option value="">-- Pilih Indikator Kinerja Urusan --</option>');
                $('#id_program').html('<option value="">-- Pilih Program --</option>');
                $('#id_kegiatan').html('<option value="">-- Pilih Kegiatan --</option>');
                $('#id_subkegiatan').html('<option value="">-- Pilih Sub Kegiatan --</option>');
                $('#id_indikator').html('<option value="">-- Pilih Indikator --</option>');
                $('#id_satuan').html('<option value="">-- Pilih Satuan --</option>');
            }
        });

        $('#id_indikator_kinerja_urusan').change(function() {
            var indikatorKinerjaID = $(this).val();
            if (indikatorKinerjaID != '') {
                $.ajax({
                    url: '/perencanaan/getProgramByIndikatorKinerja/' + indikatorKinerjaID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_program').html('<option value="">-- Pilih Program --</option>');
                        $.each(data, function(key, value) {
                            $('#id_program').append('<option value="' + value.id + '">' + value.nama_program + '</option>');
                        });
                    }
                });
            } else {
                $('#id_program').html('<option value="">-- Pilih Program --</option>');
                $('#id_kegiatan').html('<option value="">-- Pilih Kegiatan --</option>');
                $('#id_subkegiatan').html('<option value="">-- Pilih Sub Kegiatan --</option>');
                $('#id_indikator').html('<option value="">-- Pilih Indikator --</option>');
                $('#id_satuan').html('<option value="">-- Pilih Satuan --</option>');
            }
        });


        $('#id_program').change(function() {
            var programID = $(this).val();
            if (programID != '') {
                $.ajax({
                    url: '/perencanaan/getKegiatanByProgram/' + programID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_kegiatan').html('<option value="">-- Pilih Kegiatan --</option>');
                        $.each(data, function(key, value) {
                            $('#id_kegiatan').append('<option value="' + value.id + '">' + value.nama_kegiatan + '</option>');
                        });
                    }
                });
            } else {
                $('#id_kegiatan').html('<option value="">-- Pilih Kegiatan --</option>');
                $('#id_subkegiatan').html('<option value="">-- Pilih Sub Kegiatan --</option>');
                $('#id_indikator').html('<option value="">-- Pilih Indikator --</option>');
                $('#id_satuan').html('<option value="">-- Pilih Satuan --</option>');
            }
        });

        $('#id_kegiatan').change(function() {
            var kegiatanID = $(this).val();
            if (kegiatanID != '') {
                $.ajax({
                    url: '/perencanaan/getSubKegiatanByKegiatan/' + kegiatanID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_subkegiatan').html('<option value="">-- Pilih Sub Kegiatan --</option>');
                        $.each(data, function(key, value) {
                            $('#id_subkegiatan').append('<option value="' + value.id + '">' + value.nama_subkegiatan + '</option>');
                        });
                    }
                });
            } else {
                $('#id_subkegiatan').html('<option value="">-- Pilih Sub Kegiatan --</option>');
                $('#id_indikator').html('<option value="">-- Pilih Indikator --</option>');
                $('#id_satuan').html('<option value="">-- Pilih Satuan --</option>');
            }
        });

        $('#id_subkegiatan').change(function() {
            var subkegiatanID = $(this).val();
            if (subkegiatanID != '') {
                $.ajax({
                    url: '/perencanaan/getIndikatorBySubKegiatan/' + subkegiatanID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_indikator').html('<option value="">-- Pilih Indikator --</option>');
                        $.each(data, function(key, value) {
                            $('#id_indikator').append('<option value="' + value.id + '">' + value.nama_indikator + '</option>');
                        });
                    }
                });
            } else {
                $('#id_indikator').html('<option value="">-- Pilih Indikator --</option>');
                $('#id_satuan').html('<option value="">-- Pilih Satuan --</option>');
            }
        });

        $('#id_indikator').change(function() {
            var indikatorID = $(this).val();
            if (indikatorID != '') {
                $.ajax({
                    url: '/perencanaan/getSatuanByIndikator/' + indikatorID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_satuan').html('<option value="">-- Pilih Satuan --</option>');
                        $.each(data, function(key, value) {
                            $('#id_satuan').append('<option value="' + value.id + '">' + value.nama_satuan + '</option>');
                        });
                    }
                });
            } else {
                $('#id_satuan').html('<option value="">-- Pilih Satuan --</option>');
            }
        });
    });
</script>

<?= $this->endSection(); ?>
