<?= $this->extend('templates/main'); ?>

<?= $this->section('content'); ?>

<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Form <?= $title; ?></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="#"><?= $title; ?></a></div>
                <div class="breadcrumb-item">Create</div>
            </div>
        </div>

        <div class="section-body">
            <h2 class="section-title">Form <?= $title; ?></h2>
            <p class="section-lead">
                Silakan isi formulir di bawah ini.
            </p>

            <!-- Form untuk menambahkan Sub Kegiatan -->
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Form <?= $title; ?></h4>
                        </div>
                        <div class="card-body">
                            <!-- Form untuk menambahkan Sub Kegiatan -->
                            <form action="<?= route_to('sub-kegiatan/store'); ?>" method="post">
                                <?= csrf_field(); ?>

                                <!-- Dropdown/select option untuk memilih Urusan -->
                                <div class="form-group">
                                    <label>Urusan</label>
                                    <select class="form-control <?= (session('errors.id_urusan')) ? 'is-invalid' : ''; ?>" id="id_urusan" name="id_urusan">
                                        <option value="">-- Pilih Urusan --</option>
                                        <?php foreach ($urusan as $u) : ?>
                                            <option value="<?= $u['id']; ?>"><?= $u['nama_urusan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?php if (session('errors.id_urusan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.id_urusan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Dropdown/select option untuk memilih Indikator Kinerja Urusan -->
                                <div class="form-group">
                                    <label>Indikator Kinerja Urusan</label>
                                    <select class="form-control <?= (session('errors.id_indikator_kinerja_urusan')) ? 'is-invalid' : ''; ?>" id="id_indikator_kinerja_urusan" name="id_indikator_kinerja_urusan">
                                        <option value="">-- Pilih Indikator Kinerja Urusan --</option>
                                    </select>
                                    <?php if (session('errors.id_indikator_kinerja_urusan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.id_indikator_kinerja_urusan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Dropdown/select option untuk memilih Program -->
                                <div class="form-group">
                                    <label>Program</label>
                                    <select class="form-control <?= (session('errors.id_program')) ? 'is-invalid' : ''; ?>" id="id_program" name="id_program">
                                        <option value="">-- Pilih Program --</option>
                                    </select>
                                    <?php if (session('errors.id_program')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.id_program'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Dropdown/select option untuk memilih Kegiatan -->
                                <div class="form-group">
                                    <label>Kegiatan</label>
                                    <select class="form-control <?= (session('errors.id_kegiatan')) ? 'is-invalid' : ''; ?>" id="id_kegiatan" name="id_kegiatan">
                                        <option value="">-- Pilih Kegiatan --</option>
                                    </select>
                                    <?php if (session('errors.id_kegiatan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.id_kegiatan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Input untuk Nama Sub Kegiatan -->
                                <div class="form-group">
                                    <label>Nama Sub Kegiatan</label>
                                    <input type="text" class="form-control <?= (session('errors.nama_subkegiatan')) ? 'is-invalid' : ''; ?>" id="nama_subkegiatan" name="nama_subkegiatan" placeholder="Tambahkan Nama Sub Kegiatan" value="<?= old('nama_subkegiatan'); ?>">
                                    <?php if (session('errors.nama_subkegiatan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.nama_subkegiatan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Tombol Submit -->
                                <div class="card-footer text-right">
                                    <button class="btn btn-primary">Tambah</button>
                                    <a href="<?= base_url('/sub-kegiatan'); ?>" class="btn btn-secondary">Batal</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Form untuk menambahkan Sub Kegiatan -->
        </div>
    </section>
</div>

<!-- script dc jquery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- JavaScript untuk Dropdown Berantai -->
<script>
    $(document).ready(function() {
        $('#id_urusan').change(function() {
            var urusanID = $(this).val();
            if (urusanID != '') {
                $.ajax({
                    url: '/sub-kegiatan/getIndikatorKinerjaByUrusan/' + urusanID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_indikator_kinerja_urusan').html('<option value="">-- Pilih Indikator Kinerja Urusan --</option>');
                        $.each(data, function(key, value) {
                            $('#id_indikator_kinerja_urusan').append('<option value="' + value.id + '">' + value.nama_indikator_kinerja + '</option>');
                        });
                    }
                });
            } else {
                $('#id_indikator_kinerja_urusan').html('<option value="">-- Pilih Indikator Kinerja Urusan --</option>');
                $('#id_program').html('<option value="">-- Pilih Program --</option>');
            }
        });

        $('#id_indikator_kinerja_urusan').change(function() {
            var indikatorKinerjaID = $(this).val();
            if (indikatorKinerjaID != '') {
                $.ajax({
                    url: '/sub-kegiatan/getProgramByIndikator/' + indikatorKinerjaID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_program').html('<option value="">-- Pilih Program --</option>');
                        $.each(data, function(key, value) {
                            $('#id_program').append('<option value="' + value.id + '">' + value.nama_program + '</option>');
                        });
                    }
                });
            } else {
                $('#id_program').html('<option value="">-- Pilih Program --</option>');
            }
        });
    });

    // dropdown kegiatan
    $(document).ready(function() {
        $('#id_program').change(function() {
            var programID = $(this).val();
            if (programID != '') {
                $.ajax({
                    url: '/sub-kegiatan/getKegiatanByProgram/' + programID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_kegiatan').html('<option value="">-- Pilih Kegiatan --</option>');
                        $.each(data, function(key, value) {
                            $('#id_kegiatan').append('<option value="' + value.id + '">' + value.nama_kegiatan + '</option>');
                        });
                    }
                });
            } else {
                $('#id_kegiatan').html('<option value="">-- Pilih Kegiatan --</option>');
            }
        });
    });

</script>

<?= $this->endSection(); ?>
