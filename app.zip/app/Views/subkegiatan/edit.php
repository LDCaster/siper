<?= $this->extend('templates/main'); ?>

<?= $this->section('content'); ?>

<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Form Edit <?= $title; ?></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="#"><?= $title; ?></a></div>
                <div class="breadcrumb-item">Edit</div>
            </div>
        </div>

        <div class="section-body">
            <h2 class="section-title">Form Edit <?= $title; ?></h2>
            <p class="section-lead">
                Ini merupakan form untuk mengedit <?= $title; ?>.
            </p>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <!-- Form untuk mengedit Sub Kegiatan Urusan -->
                        <form action="<?= route_to('sub-kegiatan/update', $subkegiatan['id']); ?>" method="post">
                            <?= csrf_field(); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label>Pilih Urusan</label>
                                    <select name="id_urusan" id="id_urusan" class="form-control">
                                        <?php foreach ($urusan as $urusan) : ?>
                                            <option value="<?= $urusan['id']; ?>" <?= ($urusan['id'] == $subkegiatan['id_urusan']) ? 'selected' : ''; ?>><?= $urusan['nama_urusan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Pilih Indikator Kinerja</label>
                                    <select name="id_indikator_kinerja_urusan" id="id_indikator_kinerja_urusan" class="form-control">
                                        <?php foreach ($indikatorKinerjaUrusan as $indikator) : ?>
                                            <option value="<?= $indikator['id']; ?>" <?= ($indikator['id'] == $subkegiatan['id_indikator_kinerja_urusan']) ? 'selected' : ''; ?>><?= $indikator['nama_indikator_kinerja']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Dropdown/select option untuk memilih Program -->
                                <div class="form-group">
                                    <label>Pilih Program</label>
                                    <select name="id_program" id="id_program" class="form-control">
                                        <?php foreach ($program as $program) : ?>
                                            <option value="<?= $program['id']; ?>" <?= ($program['id'] == $subkegiatan['id_program']) ? 'selected' : ''; ?>><?= $program['nama_program']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Dropdown/select option untuk memilih Kegiatan -->
                                <div class="form-group">
                                    <label>Pilih Kegiatan</label>
                                    <select name="id_kegiatan" id="id_kegiatan" class="form-control">
                                        <?php foreach ($kegiatan as $kegiatan) : ?>
                                            <option value="<?= $kegiatan['id']; ?>" <?= ($kegiatan['id'] == $subkegiatan['id_kegiatan']) ? 'selected' : ''; ?>><?= $kegiatan['nama_kegiatan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Input untuk nama SUb Kegiatan -->

                                <div class="form-group">
                                    <label>Nama Sub Kegiatan</label>
                                    <input type="text" class="form-control <?= (session('errors.nama_subkegiatan')) ? 'is-invalid' : ''; ?>" id="nama_subkegiatan" name="nama_subkegiatan" value="<?= $subkegiatan['nama_subkegiatan']; ?>">
                                    <?php if (session('errors.nama_subkegiatan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.nama_subkegiatan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <!-- Tombol Submit dan Batal -->
                                <div class="card-footer text-right">
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                    <a href="<?= base_url('/sub-kegiatan'); ?>" class="btn btn-secondary">Batal</a>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- script dc jquery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- JavaScript untuk Dropdown Berantai -->
<script>
    $(document).ready(function() {
        $('#id_urusan').change(function() {
            var urusanID = $(this).val();
            if (urusanID != '') {
                $.ajax({
                    url: '/sub-kegiatan/getIndikatorKinerjaByUrusan/' + urusanID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_indikator_kinerja_urusan').html('<option value="">-- Pilih Indikator Kinerja Urusan --</option>');
                        $.each(data, function(key, value) {
                            $('#id_indikator_kinerja_urusan').append('<option value="' + value.id + '">' + value.nama_indikator_kinerja + '</option>');
                        });
                    }
                });
            } else {
                $('#id_indikator_kinerja_urusan').html('<option value="">-- Pilih Indikator Kinerja Urusan --</option>');
                $('#id_program').html('<option value="">-- Pilih Program --</option>');
            }
        });

        $('#id_indikator_kinerja_urusan').change(function() {
            var indikatorKinerjaID = $(this).val();
            if (indikatorKinerjaID != '') {
                $.ajax({
                    url: '/sub-kegiatan/getProgramByIndikator/' + indikatorKinerjaID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_program').html('<option value="">-- Pilih Program --</option>');
                        $.each(data, function(key, value) {
                            $('#id_program').append('<option value="' + value.id + '">' + value.nama_program + '</option>');
                        });
                    }
                });
            } else {
                $('#id_program').html('<option value="">-- Pilih Program --</option>');
            }
        });
    });

    // dropdown kegiatan
    $(document).ready(function() {
        $('#id_program').change(function() {
            var programID = $(this).val();
            if (programID != '') {
                $.ajax({
                    url: '/sub-kegiatan/getKegiatanByProgram/' + programID,
                    type: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $('#id_kegiatan').html('<option value="">-- Pilih Kegiatan --</option>');
                        $.each(data, function(key, value) {
                            $('#id_kegiatan').append('<option value="' + value.id + '">' + value.nama_kegiatan + '</option>');
                        });
                    }
                });
            } else {
                $('#id_kegiatan').html('<option value="">-- Pilih Kegiatan --</option>');
            }
        });
    });

</script>

<?= $this->endSection(); ?>