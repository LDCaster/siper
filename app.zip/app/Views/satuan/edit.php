<?= $this->extend('templates/main'); ?>

<?= $this->section('content'); ?>

<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Form Edit <?= $title; ?></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="#"><?= $title; ?></a></div>
                <div class="breadcrumb-item">Edit</div>
            </div>
        </div>

        <div class="section-body">
            <h2 class="section-title">Form Edit <?= $title; ?></h2>
            <p class="section-lead">
                Ini merupakan form untuk mengedit <?= $title; ?>.
            </p>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <!-- Form untuk mengedit Satuan Urusan -->
                        <form action="<?= route_to('satuan/update', $satuan['id']); ?>" method="post">
                            <?= csrf_field(); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label>Pilih Urusan</label>
                                    <select name="id_urusan" id="id_urusan" class="form-control">
                                        <?php foreach ($urusan as $urusan) : ?>
                                            <option value="<?= $urusan['id']; ?>" <?= ($urusan['id'] == $satuan['id_urusan']) ? 'selected' : ''; ?>><?= $urusan['nama_urusan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Pilih Indikator Kinerja</label>
                                    <select name="id_indikator_kinerja_urusan" id="id_indikator_kinerja_urusan" class="form-control">
                                        <?php foreach ($indikatorKinerjaUrusan as $indikators) : ?>
                                            <option value="<?= $indikators['id']; ?>" <?= ($indikators['id'] == $satuan['id_indikator_kinerja_urusan']) ? 'selected' : ''; ?>><?= $indikators['nama_indikator_kinerja']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Dropdown/select option untuk memilih Program -->
                                <div class="form-group">
                                    <label>Pilih Program</label>
                                    <select name="id_program" id="id_program" class="form-control">
                                        <?php foreach ($program as $program) : ?>
                                            <option value="<?= $program['id']; ?>" <?= ($program['id'] == $satuan['id_program']) ? 'selected' : ''; ?>><?= $program['nama_program']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Dropdown/select option untuk memilih Kegiatan -->
                                <div class="form-group">
                                    <label>Pilih Kegiatan</label>
                                    <select name="id_kegiatan" id="id_kegiatan" class="form-control">
                                        <?php foreach ($kegiatan as $kegiatan) : ?>
                                            <option value="<?= $kegiatan['id']; ?>" <?= ($kegiatan['id'] == $satuan['id_kegiatan']) ? 'selected' : ''; ?>><?= $kegiatan['nama_kegiatan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Dropdown/select option untuk memilih Sub Kegiatan -->
                                <div class="form-group">
                                    <label>Pilih Sub Kegiatan</label>
                                    <select name="id_subkegiatan" id="id_subkegiatan" class="form-control">
                                        <?php foreach ($subkegiatan as $subkegiatan) : ?>
                                            <option value="<?= $subkegiatan['id']; ?>" <?= ($subkegiatan['id'] == $satuan['id_subkegiatan']) ? 'selected' : ''; ?>><?= $subkegiatan['nama_subkegiatan']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- Dropdown/select option untuk memilih Indikator Sub Kegiatan -->
                                <div class="form-group">
                                    <label>Pilih Indikator Sub Kegiatan</label>
                                    <select name="id_indikator" id="id_indikator" class="form-control">
                                        <?php foreach ($indikator as $indikator) : ?>
                                            <option value="<?= $indikator['id']; ?>" <?= ($indikator['id'] == $satuan['id_indikator']) ? 'selected' : ''; ?>><?= $indikator['nama_indikator']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                

                                <!-- Input untuk nama Satuan -->

                                <div class="form-group">
                                    <label>Nama Satuan</label>
                                    <input type="text" class="form-control <?= (session('errors.nama_satuan')) ? 'is-invalid' : ''; ?>" id="nama_satuan" name="nama_satuan" value="<?= $satuan['nama_satuan']; ?>">
                                    <?php if (session('errors.nama_satuan')) : ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.nama_satuan'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <!-- Tombol Submit dan Batal -->
                                <div class="card-footer text-right">
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                    <a href="<?= route_to('satuan/index'); ?>" class="btn btn-secondary">Batal</a>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?= $this->endSection(); ?>