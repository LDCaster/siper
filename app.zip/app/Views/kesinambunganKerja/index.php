<?= $this->extend('templates/main'); ?>

<?= $this->section('content'); ?>

<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Kesinambungan Kinerja</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="#">Modules</a></div>
                <div class="breadcrumb-item">DataTables</div>
            </div>
        </div>

        <div class="section-body">
            <h2 class="section-title">Data Kesinambungan Kinerja</h2>
            <p class="section-lead">
                Ini merupakan data Kesinambungan Kinerja yang terdaftar di Dispusip.
            </p>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>TABEL DATA KESINAMBUNGAN KINERJA</h4>
                        </div>
                        <div class="card-body">
                            <!-- <div class="buttons" style="margin-top: -20px;">
                                <a href="/pelaporan/create" class="btn btn-primary">Tambah</a>
                            </div> -->
                            <div class="table-responsive">
                                <table class="table table-striped" id="table-2">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Urusan</th>
                                            <!-- <th>Indikator Urusan</th> -->
                                            <th>Program</th>
                                            <th>Kegiatan</th>
                                            <th>SubKegiatan</th>
                                            <!-- <th>Indikator Subkegiatan</th> -->
                                            <th>Realisasi Rp. </th>
                                            <th>Realisasi %</th>
                                            <th>Satuan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; ?>
                                        <?php foreach ($pelaporans as $pelaporan) : ?>
                                       
                                            <tr>
                                                <td><?= $no++ ?></td>
                                                <td><?= $pelaporan['urusan']; ?></td>
                                                
                                                <td><?= $pelaporan['program']; ?></td>
                                                <td><?= $pelaporan['kegiatan']; ?></td>
                                                <td><?= $pelaporan['sub_kegiatan']; ?></td>
                                             <td><?= $pelaporan['realisasi_nominal']; ?></td>
                                                <td><?= $pelaporan['realisasi_persen']; ?></td>
                                                <td><?= $pelaporan['nama_satuan']; ?></td>
                                                
                                                
                                            </tr>
                                        
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?= $this->endSection(); ?>

