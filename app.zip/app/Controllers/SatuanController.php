<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\IndikatorKinerjaUrusanModel;
use App\Models\SatuanModel;
use App\Models\UrusanModel;
use App\Models\ProgramModel;
use App\Models\KegiatanModel;
use App\Models\SubKegiatanModel;
use App\Models\IndikatorModel;

class SatuanController extends BaseController
{

    protected $satuanModel;
    protected $indikatorKinerjaUrusanModel;
    protected $urusanModel;
    protected $programModel;
    protected $kegiatanModel;
    protected $subkegiatanModel;
    protected $indikatorModel;

    public function __construct()
    {
        $this->satuanModel = new SatuanModel();
        $this->indikatorKinerjaUrusanModel = new IndikatorKinerjaUrusanModel();
        $this->urusanModel = new UrusanModel();
        $this->programModel = new ProgramModel();
        $this->kegiatanModel = new KegiatanModel();
        $this->subkegiatanModel = new SubKegiatanModel();
        $this->indikatorModel = new IndikatorModel();
    }

    public function index()
    {
        $satuan = $this->satuanModel->getSatuan();
        // dd($satuan);

        $data = [
            'title' => 'Satuan',
            'satuan' => $satuan,
        ];

        return view('satuan/index', $data);
    }

    public function create()
    {
        // Mengambil data Urusan untuk digunakan dalam form create
        $urusan = $this->urusanModel->findAll();
        $indikatorKinerjaUrusan = $this->indikatorKinerjaUrusanModel->findAll();
        $program = $this->programModel->findAll();
        $kegiatan = $this->kegiatanModel->findAll();
        $subkegiatan = $this->subkegiatanModel->findAll();
        $indikator = $this->indikatorModel->findAll();

        $data = [
            'title' => 'Tambah Data Satuan',
            'validation' => \Config\Services::validation(),
            'urusan' => $urusan,
            'indikatorKinerjaUrusan' => $indikatorKinerjaUrusan,
            'program' => $program,
            'kegiatan' => $kegiatan,
            'subkegiatan' => $subkegiatan,
            'indikator' => $indikator,
        ];

        return view('satuan/create', $data);
    }

    public function store()
    {
        // validasi
        $validationRules = [
            'nama_satuan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Satuan Harus Diisi',
                ]
            ],
            'id_urusan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Urusan Harus Diisi',
                ]
            ],
            'id_indikator_kinerja_urusan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Indikator Kinerja Harus Diisi',
                ]
            ],
            'id_program' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Program Harus Diisi',
                ]
            ],
            'id_kegiatan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom kegiatan Harus Diisi',
                ]
            ],
            'id_subkegiatan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Sub Kegiatan Harus Diisi',
                ]
            ],
            'id_indikator' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Indikator Harus Diisi',
                ]
            ],
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // ambil data dari form
        $nama_satuan = $this->request->getPost('nama_satuan');
        $id_urusan = $this->request->getPost('id_urusan');
        $id_indikator_kinerja_urusan = $this->request->getPost('id_indikator_kinerja_urusan');

        // membuat array collection yang disiapkan untuk insert ke table
        $data = [
            'nama_satuan' => $this->request->getPost('nama_satuan'),
            'id_urusan' => $this->request->getPost('id_urusan'),
            'id_indikator_kinerja_urusan' => $this->request->getPost('id_indikator_kinerja_urusan'),
            'id_program' => $this->request->getPost('id_program'),
            'id_kegiatan' => $this->request->getPost('id_kegiatan'),
            'id_subkegiatan' => $this->request->getPost('id_subkegiatan'),
            'id_indikator' => $this->request->getPost('id_indikator'),
        ];


        // insert ke table
        $simpan = $this->satuanModel->insert($data);


        // cek jika proses simpan gagal
        if (!$simpan) {
            // redirect ke halaman create
            session()->setFlashdata('pesan', 'Data Gagal ditambahkan!');
            return redirect()->to('satuan/create');
        }
        // jika berhasil
        else {
            // redirect ke halaman index
            session()->setFlashdata('pesan', 'Data Berhasil ditambahkan!');
            return redirect()->to('/satuan');
        }
    }

    public function edit($id)
    {
        // Mengambil data satuan berdasarkan ID
        $satuan = $this->satuanModel->find($id);
        $urusan = $this->urusanModel->findAll();
        // dd($urusan);
        $indikatorKinerjaUrusan = $this->indikatorKinerjaUrusanModel->findAll();
        $program = $this->programModel->findAll();
        $kegiatan = $this->kegiatanModel->findAll();
        $subkegiatan = $this->subkegiatanModel->findAll();
        $indikator = $this->indikatorModel->findAll();

        $data = [
            'title' => 'Edit Data Satuan',
            'validation' => \Config\Services::validation(),
            'satuan' => $satuan,
            'urusan' => $urusan,
            'indikatorKinerjaUrusan' => $indikatorKinerjaUrusan,
            'program' => $program,
            'kegiatan' => $kegiatan,
            'subkegiatan' => $subkegiatan,
            'indikator' => $indikator,

        ];

        return view('satuan/edit', $data);
    }

    public function update($id)
    {
        // validasi
        $validationRules = [
            'nama_satuan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Satuan Harus Diisi',
                ]
            ],
            'id_urusan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Urusan Harus Diisi',
                ]
            ],
            'id_indikator_kinerja_urusan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Indikator Kinerja Harus Diisi',
                ]
            ],
            'id_program' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Program Harus Diisi',
                ]
            ],
            'id_kegiatan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom kegiatan Harus Diisi',
                ]
            ],
            'id_subkegiatan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Sub Kegiatan Harus Diisi',
                ]
            ],
            'id_indikator' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Kolom Indikator Harus Diisi',
                ]
            ],
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }


        $simpan = $this->satuanModel->update($id, [
            'nama_satuan' => $this->request->getPost('nama_satuan'),
            'id_urusan' => $this->request->getPost('id_urusan'),
            'id_indikator_kinerja_urusan' => $this->request->getPost('id_indikator_kinerja_urusan'),
            'id_program' => $this->request->getPost('id_program'),
            'id_kegiatan' => $this->request->getPost('id_kegiatan'),
            'id_subkegiatan' => $this->request->getPost('id_subkegiatan'),
            'id_indikator' => $this->request->getPost('id_indikator'),
        ]);

        // cek jika proses simpan gagal
        if (!$simpan) {
            // redirect ke halaman create
            session()->setFlashdata('pesan', 'Data Gagal diubah!');
            return redirect()->to('/satuan/edit/' . $id);
        }
        // jika berhasil
        else {
            // redirect ke halaman index
            session()->setFlashdata('pesan', 'Data Berhasil diubah!');
            return redirect()->to('/satuan');
        }
    }

    public function destroy($id)
    {
        // Menghapus data satuan berdasarkan ID
        // Gunakan model untuk melakukan penghapusan
        $simpan = $this->satuanModel->delete($id);

        // cek jika proses simpan gagal
        if (!$simpan) {
            // redirect ke halaman create
            session()->setFlashdata('pesan', 'Data Gagal dihapus!');
            return redirect()->to('/satuan');
        }
        // jika berhasil
        else {
            // redirect ke halaman index
            session()->setFlashdata('pesan', 'Data Berhasil dihapus!');
            return redirect()->to('/satuan');
        }
    }

    // Fungsi untuk mengambil data Indikator Kinerja Urusan berdasarkan Urusan yang dipilih (digunakan untuk dropdown berantai)
    public function getIndikatorKinerjaByUrusan($id_urusan)
    {
        $indikatorKinerjaUrusan = $this->satuanModel->getIndikatorKinerjaByUrusan($id_urusan);
        return $this->response->setJSON($indikatorKinerjaUrusan);
    }

    // Fungsi untuk mengambil data Program berdasarkan Indikator Kinerja Urusan yang dipilih (digunakan untuk dropdown berantai)
    public function getProgramByIndikator($id_indikator_kinerja_urusan)
    {
        $program = $this->satuanModel->getProgramByIndikator($id_indikator_kinerja_urusan);
        return $this->response->setJSON($program);
    }

    // Fungsi untuk mengambil data Kegiatan berdasarkan Program yang dipilih (digunakan untuk dropdown berantai)
    public function getKegiatanByProgram($id_program)
    {
        $kegiatan = $this->satuanModel->getKegiatanByProgram($id_program);
        return $this->response->setJSON($kegiatan);
    }

    public function getSubKegiatanByKegiatan($id_kegiatan)
    {
        $subkegiatan = $this->satuanModel->getSubKegiatanByKegiatan($id_kegiatan);
        return $this->response->setJSON($subkegiatan);
    }

    public function getIndikatorBySubKegiatan($id_subkegiatan)
    {
        $indikator = $this->satuanModel->getIndikatorBySubKegiatan($id_subkegiatan);
        return $this->response->setJSON($indikator);
    }
}
