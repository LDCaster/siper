<?php

namespace App\Controllers;


use App\Controllers\BaseController;
use App\Models\PerencanaanModel;
use App\Models\UrusanModel;
use App\Models\IndikatorKinerjaUrusanModel;
use App\Models\ProgramModel;
use App\Models\KegiatanModel;
use App\Models\SubKegiatanModel;
use App\Models\IndikatorModel;
use App\Models\SatuanModel;

use Dompdf\Dompdf;


class PerencanaanController extends BaseController
{
    protected $perencanaanModel;
    protected $urusanModel;
    protected $indikatorKinerjaUrusanModel;
    protected $programModel;
    protected $kegiatanModel;
    protected $subKegiatanModel;
    protected $indikatorModel;
    protected $satuanModel;

    public function __construct()
    {
        $this->perencanaanModel = new PerencanaanModel();
        $this->urusanModel = new UrusanModel();
        $this->indikatorKinerjaUrusanModel = new IndikatorKinerjaUrusanModel();
        $this->programModel = new ProgramModel();
        $this->kegiatanModel = new KegiatanModel();
        $this->subKegiatanModel = new SubKegiatanModel();
        $this->indikatorModel = new IndikatorModel();
        $this->satuanModel = new SatuanModel();
    }

    public function indexRakortekbang()
    {
        $data['perencanaan'] = $this->perencanaanModel->getPerencanaan();
        // dd($data);

        return view('perencanaan/rakortekbang/index', $data);
    }
    public function indexRenja()
    {
        $data['perencanaan'] = $this->perencanaanModel->getPerencanaan();
        return view('perencanaan/renja/index', $data);
    }

    public function createRakortekbang()
    {
        $urusan = $this->urusanModel->findAll();
        $indikatorKinerjaUrusan = $this->indikatorKinerjaUrusanModel->findAll();
        $program = $this->programModel->findAll();
        $kegiatan = $this->kegiatanModel->findAll();
        $subkegiatan = $this->subKegiatanModel->findAll();
        $indikator = $this->indikatorModel->findAll();
        $satuan = $this->satuanModel->findAll();


        $data = [
            'urusan' => $urusan,
            'indikatorKinerjaUrusan' => $indikatorKinerjaUrusan,
            'program' => $program,
            'kegiatan' => $kegiatan,
            'subkegiatan' => $subkegiatan,
            'indikator' => $indikator,
            'satuan' => $satuan,
        ];

        return view('perencanaan/rakortekbang/create' , $data);
    }

    public function createRenja()
    {
        $urusan = $this->urusanModel->findAll();
        $indikatorKinerjaUrusan = $this->indikatorKinerjaUrusanModel->findAll();
        $program = $this->programModel->findAll();
        $kegiatan = $this->kegiatanModel->findAll();
        $subkegiatan = $this->subKegiatanModel->findAll();
        $indikator = $this->indikatorModel->findAll();
        $satuan = $this->satuanModel->findAll();

        $data = [
            'urusan' => $urusan,
            'indikatorKinerjaUrusan' => $indikatorKinerjaUrusan,
            'program' => $program,
            'kegiatan' => $kegiatan,
            'subkegiatan' => $subkegiatan,
            'indikator' => $indikator,
            'satuan' => $satuan,
        ];

        return view('perencanaan/renja/create' , $data);
    }

    public function store()
    {
        // Validasi input
        $validation = \Config\Services::validation();
        $validation->setRules([
            'id_urusan' => 'required',
            'id_indikator_kinerja_urusan' => 'required',
            'id_program' => 'required',
            'id_kegiatan' => 'required',
            'id_subkegiatan' => 'required',
            'id_indikator' => 'required',
            'id_satuan' => 'required',
            'pagu_indikatif' => 'required|numeric',
            'target' => 'required|numeric',
            'status_perencanaan' => 'required',
            'status_tujuan' => 'required',
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        // Proses penyimpanan data perencanaan ke database
        $data = [
            'id_urusan' => $this->request->getPost('id_urusan'),
            'id_indikator_kinerja_urusan' => $this->request->getPost('id_indikator_kinerja_urusan'),
            'id_program' => $this->request->getPost('id_program'),
            'id_kegiatan' => $this->request->getPost('id_kegiatan'),
            'id_subkegiatan' => $this->request->getPost('id_subkegiatan'),
            'id_indikator' => $this->request->getPost('id_indikator'),
            'id_satuan' => $this->request->getPost('id_satuan'),
            'pagu_indikatif' => $this->request->getPost('pagu_indikatif'),
            'target' => $this->request->getPost('target'),
            'status_perencanaan' => $this->request->getPost('status_perencanaan'),
            'status_tujuan' => $this->request->getPost('status_tujuan'),
        ];

        $simpan = $this->perencanaanModel->insert($data);

        // cek jika gagal menyimpan ke database dengan session
        if (!$simpan) {
            session()->setFlashdata('pesan', 'Data gagal ditambahkan!');
            return redirect()->back()->withInput();
        }

        // Cek jika status perencanaan = rakortekbang maka redirect ke halaman rakortekbang jika tidak maka redirect ke halaman renja
        if ($simpan) {
            if ($this->request->getPost('status_perencanaan') === 'rakortekbang') {
                session()->setFlashdata('pesan', 'Data Berhasil ditambahkan!');
                return redirect()->to('/perencanaan/index/rakor')->with('success', 'Data perencanaan berhasil disimpan.');
            } else {
                session()->setFlashdata('pesan', 'Data Berhasil ditambahkan!');
                return redirect()->to('/perencanaan/index/renja')->with('success', 'Data perencanaan berhasil disimpan.');
            }
        } 


    }

    public function show($id)
    {
        $data['perencanaan'] = $this->perencanaanModel->find($id);

        return view('perencanaan/show', $data);
    }

    public function edit($id)
    {
        $data['urusan'] = $this->urusanModel->findAll();
        $data['indikatorKinerjaUrusan'] = $this->indikatorKinerjaUrusanModel->findAll();
        $data['program'] = $this->programModel->findAll();
        $data['kegiatan'] = $this->kegiatanModel->findAll();
        $data['subKegiatan'] = $this->subKegiatanModel->findAll();
        $data['indikator'] = $this->indikatorModel->findAll();
        $data['satuan'] = $this->satuanModel->findAll();
        $data['perencanaan'] = $this->perencanaanModel->find($id);

        return view('perencanaan/edit', $data);
    }

    public function update($id)
    {
        // Validasi input
        $validation = \Config\Services::validation();
        $validation->setRules([
            'id_urusan' => 'required',
            'id_indikator_kinerja_urusan' => 'required',
            'id_program' => 'required',
            'id_kegiatan' => 'required',
            'id_subkegiatan' => 'required',
            'id_indikator' => 'required',
            'id_satuan' => 'required',
            'pagu_indikatif' => 'required|numeric',
            'target' => 'required|numeric',
            'status_perencanaan' => 'required',
            'status_tujuan' => 'required',
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        // Proses pembaruan data perencanaan di database
        $data = [
            'id_urusan' => $this->request->getPost('id_urusan'),
            'id_indikator_kinerja_urusan' => $this->request->getPost('id_indikator_kinerja_urusan'),
            'id_program' => $this->request->getPost('id_program'),
            'id_kegiatan' => $this->request->getPost('id_kegiatan'),
            'id_subkegiatan' => $this->request->getPost('id_subkegiatan'),
            'id_indikator' => $this->request->getPost('id_indikator'),
            'id_satuan' => $this->request->getPost('id_satuan'),
            'pagu_indikatif' => $this->request->getPost('pagu_indikatif'),
            'target' => $this->request->getPost('target'),
            'status_perencanaan' => $this->request->getPost('status_perencanaan'),
            'status_tujuan' => $this->request->getPost('status_tujuan'),
        ];

        $this->perencanaanModel->update($id, $data);

        return redirect()->to('/perencanaan')->with('success', 'Data perencanaan berhasil diperbarui.');
    }

    public function destroyRakor($id)
    {
        $this->perencanaanModel->delete($id);

        return redirect()->to('/perencanaan/index/rakor')->with('success', 'Data perencanaan berhasil dihapus.');
    }


    public function destroyRenja($id)
    {
        $this->perencanaanModel->delete($id);

        return redirect()->to('/perencanaan/index/renja')->with('success', 'Data perencanaan berhasil dihapus.');
    }

    // cetak pdf rakortekbang
    public function cetakRakortekbang()
    {
        $data['perencanaan'] = $this->perencanaanModel->getPerencanaanRakor();

        $dompdf = new Dompdf();
        $dompdf->loadHtml(view('/perencanaan/rakortekbang/cetak', $data));
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();
        $dompdf->stream('rakortekbang.pdf');
    }

    // tampilan cetak pdf rakortekbang
    public function cetakRakortekbangView()
    {
        $data['perencanaan'] = $this->perencanaanModel->getPerencanaanRakor();
        // dd($data);  

        return view('perencanaan/rakortekbang/cetak', $data);
    }

    // cetak pdf renja
    public function cetakRenja()
    {
        $data['perencanaan'] = $this->perencanaanModel->getPerencanaanRenja();

        $dompdf = new Dompdf();
        $dompdf->loadHtml(view('/perencanaan/renja/cetak', $data));
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();
        $dompdf->stream('renja.pdf');
    }

    // tampilan cetak pdf renja
    public function cetakRenjaView()
    {
        $data['perencanaan'] = $this->perencanaanModel->getPerencanaanRenja();
        // dd($data);  

        return view('perencanaan/renja/cetak', $data);
    }



    // fungsi untuk mengambil daftar indikator kinerja urusan berdasarkan id_urusan
    public function getIndikatorKinerjaByUrusan($idUrusan)
    {
        $indikatorKinerjaUrusan = $this->perencanaanModel->getIndikatorKinerjaByUrusan($idUrusan);
        return $this->response->setJSON($indikatorKinerjaUrusan);
    }

    // fungsi untuk mengambil daftar program berdasarkan id_indikator_kinerja_urusan
    public function getProgramByIndikatorKinerja($idIndikatorKinerja)
    {
        $program = $this->perencanaanModel->getProgramByIndikatorKinerja($idIndikatorKinerja);
        return $this->response->setJSON($program);
    }

     // Fungsi untuk mengambil daftar kegiatan berdasarkan id_program
     public function getKegiatanByProgram($idProgram)
     {
         $kegiatan = $this->perencanaanModel->getKegiatanByProgram($idProgram);
         return $this->response->setJSON($kegiatan);
        
     }
 
     // Fungsi untuk mengambil daftar subkegiatan berdasarkan id_kegiatan
     public function getSubKegiatanByKegiatan( $idKegiatan)
     {
            $subKegiatan = $this->perencanaanModel->getSubKegiatanByKegiatan($idKegiatan);
            return $this->response->setJSON($subKegiatan);
     }
 
     // Fungsi untuk mengambil daftar indikator berdasarkan id_subkegiatan
     public function getIndikatorBySubKegiatan( $idSubKegiatan)
     {
         $indikator = $this->perencanaanModel->getIndikatorBySubKegiatan($idSubKegiatan);
         return $this->response->setJSON($indikator);
     }
     
 
     // Fungsi untuk mengambil daftar satuan berdasarkan id_indikator
     public function getSatuanByIndikator( $idIndikator)
     {
         $satuan = $this->perencanaanModel->getSatuanByIndikator($idIndikator);
         return $this->response->setJSON($satuan);
     }
   
}
