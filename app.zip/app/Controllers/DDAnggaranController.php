<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DDAnggaranModel;
use CodeIgniter\HTTP\Files\UploadedFile;

class DDAnggaranController extends BaseController
{
    protected $DDAnggaranModel;

    public function __construct()
    {
        $this->DDAnggaranModel = new DDAnggaranModel();
    }

    public function index()
    {
        $data['dd_anggaran'] = $this->DDAnggaranModel->getAllData();
        return view('anggaran/datadukung/index', $data);
    }

    public function create()
    {
        return view('anggaran/datadukung/create');
    }

    public function store()
    {
        $validationRules = [
            'nama_file' => 'required',
            'file' => 'uploaded[file]|ext_in[file,pdf]|max_size[file,20240]', // Maksimal 20MB
            'tahun' => 'required'
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->to('/ddanggaran/create')->withInput()->with('validation', $this->validator);
        }

        $file = $this->request->getFile('file');

        // Pindahkan file yang diunggah ke folder yang diinginkan
        $newFileName = $file->getRandomName();
        $file->move(ROOTPATH . 'public/uploads/ddAnggaran/', $newFileName);

        // Simpan data ke database
        $this->DDAnggaranModel->save([
            'nama_file' => $this->request->getPost('nama_file'),
            'file' => $newFileName,
            'tahun' => $this->request->getPost('tahun')
        ]);

        return redirect()->to('/ddanggaran')->with('success', 'Data Dukung berhasil ditambahkan.');
    }

    // Tambahkan metode untuk menampilkan pratinjau file PDF dan terapkan mpdf
    public function preview($id)
    {
        $data['dd_detail'] = $this->DDAnggaranModel->find($id);
        return view('anggaran/datadukung/preview', $data);
    }

    public function download($id)
    {
        $data = $this->DDAnggaranModel->find($id);
        return $this->response->download(ROOTPATH . 'public/uploads/ddAnggaran/' . $data['file'], null);
    }
    
    public function destroy($id)
    {
        $data = $this->DDAnggaranModel->find($id);
        unlink(ROOTPATH . 'public/uploads/ddAnggaran/' . $data['file']); // Hapus file dari folder uploads
        $this->DDAnggaranModel->delete($id);

        return redirect()->to('/ddanggaran')->with('success', 'Data Dukung berhasil dihapus.');
    }
}
