<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\PelaporanModel;
use App\Models\AnggaranModel;

class PelaporanController extends BaseController
{
    protected $pelaporanModel;
    protected $anggaranModel;

    public function __construct()
    {
        $this->pelaporanModel = new PelaporanModel();
        $this->anggaranModel = new AnggaranModel();
    }

    public function index()
    {
        $data = [
            'pelaporans' => $this->pelaporanModel->getPelaporan(),
        
        ];
        // dd($data);

        return view('pelaporan/index', $data);
    }
    

    public function create()
    {
        // Mengambil data Karyawan untuk digunakan dalam form create
        $anggarans = $this->anggaranModel->findAll();

        return view('pelaporan/create', ['anggarans' => $anggarans]);
    }

    public function store()
    {
        // Validasi dan penyimpanan data Indikator Kinerja Urusan
        // Anda dapat menggunakan $this->request->getPost() untuk mengambil data dari form
        // Kemudian, gunakan model untuk menyimpan data sesuai kebutuhan

        // Contoh validasi
        $validationRules = [
            'id_anggaran' => 'required',
            'status' => 'required',
            'realisasi_nominal' => 'required',
            'realisasi_persen' => 'required',
        
        ];

        if ($this->validate($validationRules)) {
            // Data valid, simpan ke database
            $data = [
                'id_anggaran' => $this->request->getPost('id_anggaran'),
                'status' => $this->request->getPost('status'),
                'realisasi_nominal' => $this->request->getPost('realisasi_nominal'),
                'realisasi_persen' => $this->request->getPost('realisasi_persen'),
            ];

            $this->pelaporanModel->insert($data);

            return redirect()->to('/pelaporan');
        } else {
            // Validasi gagal, tampilkan kembali form dengan pesan error
            return view('pelaporan/create', [
                'anggarans' => $this->anggaranModel->findAll(),
                'validation' => $this->validator,
            ]);
        }
    }

    public function edit($id)
    {
        // Mengambil data Indikator Kinerja Urusan berdasarkan ID
        $pelaporan = $this->pelaporanModel->find($id);

        // Mengambil data Urusan untuk digunakan dalam form edit
        $anggarans = $this->anggaranModel->findAll();

        return view('pelaporan/edit', ['pelaporan' => $pelaporan,'anggarans' => $anggarans]);
    }

    public function update($id)
    {
        // Validasi dan pembaruan data Indikator Kinerja Urusan berdasarkan ID
        // Anda dapat menggunakan $this->request->getPost() untuk mengambil data dari form
        // Kemudian, gunakan model untuk memperbarui data sesuai kebutuhan

        // Contoh validasi
        $validationRules = [
            'id_anggaran' => 'required',
            'status' => 'required',
            'realisasi_nominal' => 'required',
            'realisasi_persen' => 'required',
        ];

        if ($this->validate($validationRules)) {
            // Data valid, update data ke database
            $data = [
                'id_anggaran' => $this->request->getPost('id_anggaran'),
                'status' => $this->request->getPost('status'),
                'realisasi_nominal' => $this->request->getPost('realisasi_nominal'),
                'realisasi_persen' => $this->request->getPost('realisasi_persen'),
            ];

            $this->pelaporanModel->update($id, $data);

            return redirect()->to('/pelaporan');
        } else {
            // Validasi gagal, tampilkan kembali form dengan pesan error
            return view('pelaporan/edit', [
                'pelaporan' => $this->pelaporanModel->find($id),
                'anggarans' => $this->anggaranModel->findAll(),
                'validation' => $this->validator,
            ]);
        }
    }

    public function destroy($id)
    {
        // Menghapus data Indikator Kinerja karyawan berdasarkan ID
        // Gunakan model untuk melakukan penghapusan
        $this->pelaporanModel->delete($id);

        return redirect()->to('/pelaporan');
    }
}
