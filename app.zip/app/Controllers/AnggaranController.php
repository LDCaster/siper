<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AnggaranModel;
use App\Models\PerencanaanModel;
use App\Models\UrusanModel;

class AnggaranController extends BaseController
{
    protected $anggaranModel;
    protected $perencanaanModel;
    protected $urusanModel;

    public function __construct()
    {
        $this->anggaranModel = new AnggaranModel();
        $this->perencanaanModel = new PerencanaanModel();
        $this->urusanModel = new UrusanModel();
    }

    public function indexPerpustakaan()
    {
        $anggaran = $this->anggaranModel->getAnggaranPerpustakaan();
        // dd($anggaran);

        $data = [
            'title' => 'Anggaran',
            'anggaran' => $anggaran,
        ];

        return view('anggaran/indexPerpustakaan', $data);
    }

    public function indexKearsipan()
    {
        $anggaran = $this->anggaranModel->getAnggaranKearsipan();
        // dd($anggaran);

        $data = [
            'title' => 'Anggaran',
            'anggaran' => $anggaran,
        ];

        return view('anggaran/indexKearsipan', $data);
    }


    public function previewCetakArsip()
    {
        return view('anggaran/previewCetakArsip');
    }

    public function previewCetakPerpus()
    {
        return view('anggaran/previewCetakPerpus');
    }

    public function cetakArsip($id)
    {
        return view('anggaran/cetakArsip');
    }

    public function cetakPerpus($id)
    {
        return view('anggaran/cetakPerpus');
    }

    public function createPerpustakaan()
    {
        // Mengambil data Urusan untuk digunakan dalam form create
        // $perencanaan = $this->perencanaanModel->findAll();
        $perpustakaan = $this->anggaranModel->getPerencanaanPerpustakaan();
        $urusan = $this->urusanModel->findAll();

        // dd($perpustakaan);

        $data = [
            'title' => 'Tambah Data Anggaran',
            'validation' => \Config\Services::validation(),
            'perpustakaan' => $perpustakaan,
            'urusan' => $urusan,
            
        ];

        return view('anggaran/createPerpustakaan', $data);
    }

    public function createKearsipan()
    {
        // Mengambil data Urusan untuk digunakan dalam form create
        // $perencanaan = $this->perencanaanModel->findAll();
        $perpustakaan = $this->anggaranModel->getPerencanaanKearsipan();
        $urusan = $this->urusanModel->findAll();
        // dd($perpustakaan);

        $data = [
            'title' => 'Tambah Data Anggaran',
            'validation' => \Config\Services::validation(),
            // 'perencanaan' => $perencanaan,
            'perpustakaan' => $perpustakaan,
            'urusan' => $urusan,
            
        ];

        return view('anggaran/createKearsipan', $data);
    }

    public function storePerpustakaan()
    {

        // membuat array collection yang disiapkan untuk insert ke table
        $data = [
            'urusan' => $this->request->getPost('urusan'),
            'program' => $this->request->getPost('program'),
            'kegiatan' => $this->request->getPost('kegiatan'),
            'sub_kegiatan' => $this->request->getPost('sub_kegiatan'),
            'sumber_pendanaan' => $this->request->getPost('sumber_pendanaan'),
            'lokasi' => $this->request->getPost('lokasi'),
            'waktu_pelaksanaan' => $this->request->getPost('waktu_pelaksanaan'),
            'kelompok_sasaran' => $this->request->getPost('kelompok_sasaran'),
            'jumlah' => $this->request->getPost('jumlah'),
            'target' => $this->request->getPost('target'),
            'id_perencanaan' => $this->request->getPost('id_perencanaan'),
        ];


        // insert ke table
        $simpan = $this->anggaranModel->insert($data);


        // cek jika proses simpan gagal
        if (!$simpan) {
            // redirect ke halaman create
            session()->setFlashdata('pesan', 'Data Gagal ditambahkan!');
            return redirect()->to('anggaran/create');
        }
        // jika berhasil
        else {
            // redirect ke halaman index
            session()->setFlashdata('pesan', 'Data Berhasil ditambahkan!');
            return redirect()->to('/anggaran/index/perpustakaan');
        }
    }

    public function storeKearsipan()
    {

        // membuat array collection yang disiapkan untuk insert ke table
        $data = [
            'urusan' => $this->request->getPost('urusan'),
            'program' => $this->request->getPost('program'),
            'kegiatan' => $this->request->getPost('kegiatan'),
            'sub_kegiatan' => $this->request->getPost('sub_kegiatan'),
            'sumber_pendanaan' => $this->request->getPost('sumber_pendanaan'),
            'lokasi' => $this->request->getPost('lokasi'),
            'waktu_pelaksanaan' => $this->request->getPost('waktu_pelaksanaan'),
            'kelompok_sasaran' => $this->request->getPost('kelompok_sasaran'),
            'jumlah' => $this->request->getPost('jumlah'),
            'target' => $this->request->getPost('target'),
            'id_perencanaan' => $this->request->getPost('id_perencanaan'),
        ];


        // insert ke table
        $simpan = $this->anggaranModel->insert($data);


        // cek jika proses simpan gagal
        if (!$simpan) {
            // redirect ke halaman create
            session()->setFlashdata('pesan', 'Data Gagal ditambahkan!');
            return redirect()->to('anggaran/createKearsipan');
        }
        // jika berhasil
        else {
            // redirect ke halaman index
            session()->setFlashdata('pesan', 'Data Berhasil ditambahkan!');
            return redirect()->to('/anggaran/index/kearsipan');
        }
    }

    public function editPerpustakaan($id)
    {
        // Mengambil data Anggaran berdasarkan ID
        $anggaran = $this->anggaranModel->find($id);
        $perencanaan = $this->perencanaanModel->find($id);
        $perpustakaan = $this->anggaranModel->getPerencanaanPerpustakaan();

        $data = [
            'title' => 'Edit Data Anggaran',
            'validation' => \Config\Services::validation(),
            'perpustakaan' => $perpustakaan,
            'perencanaan' => $perencanaan,
            'anggaran' => $anggaran,

        ];

        return view('anggaran/editPerpustakaan', $data);
    }

    public function editKearsipan($id)
    {
        // Mengambil data Anggaran berdasarkan ID
        $anggaran = $this->anggaranModel->find($id);
        $perencanaan = $this->perencanaanModel->find($id);
        $perpustakaan = $this->anggaranModel->getPerencanaanKearsipan();

        $data = [
            'title' => 'Edit Data Anggaran',
            'validation' => \Config\Services::validation(),
            'perpustakaan' => $perpustakaan,
            'perencanaan' => $perencanaan,
            'anggaran' => $anggaran,

        ];

        return view('anggaran/editKearsipan', $data);
    }

    public function updatePerpustakaan($id)
    {
        
        $simpan = $this->anggaranModel->update($id, [
            'urusan' => $this->request->getPost('urusan'),
            'program' => $this->request->getPost('program'),
            'kegiatan' => $this->request->getPost('kegiatan'),
            'sub_kegiatan' => $this->request->getPost('sub_kegiatan'),
            'sumber_pendanaan' => $this->request->getPost('sumber_pendanaan'),
            'lokasi' => $this->request->getPost('lokasi'),
            'waktu_pelaksanaan' => $this->request->getPost('waktu_pelaksanaan'),
            'kelompok_sasaran' => $this->request->getPost('kelompok_sasaran'),
            'jumlah' => $this->request->getPost('jumlah'),
            // 'id_perencanaan' => $this->request->getPost('id_perencanaan'),
        ]);
        
        // cek jika proses simpan gagal
        if (!$simpan) {
            // redirect ke halaman create
            
            session()->setFlashdata('pesan', 'Data Gagal diubah!');
            return redirect()->to('/anggaran/edit/perpustakaan/' . $id);
        }
        // jika berhasil
        else {
            
            // redirect ke halaman index
            session()->setFlashdata('pesan', 'Data Berhasil diubah!');
            return redirect()->to('/anggaran/index/perpustakaan');
        }
    }

    public function updateKearsipan($id)
    {
        
        $simpan = $this->anggaranModel->update($id, [
            'urusan' => $this->request->getPost('urusan'),
            'program' => $this->request->getPost('program'),
            'kegiatan' => $this->request->getPost('kegiatan'),
            'sub_kegiatan' => $this->request->getPost('sub_kegiatan'),
            'sumber_pendanaan' => $this->request->getPost('sumber_pendanaan'),
            'lokasi' => $this->request->getPost('lokasi'),
            'waktu_pelaksanaan' => $this->request->getPost('waktu_pelaksanaan'),
            'kelompok_sasaran' => $this->request->getPost('kelompok_sasaran'),
            'jumlah' => $this->request->getPost('jumlah'),
            // 'id_perencanaan' => $this->request->getPost('id_perencanaan'),
        ]);
        
        // cek jika proses simpan gagal
        if (!$simpan) {
            // redirect ke halaman create
            
            session()->setFlashdata('pesan', 'Data Gagal diubah!');
            return redirect()->to('/anggaran/edit/kearsipan/' . $id);
        }
        // jika berhasil
        else {
            
            // redirect ke halaman index
            session()->setFlashdata('pesan', 'Data Berhasil diubah!');
            return redirect()->to('/anggaran/index/kearsipan');
        }
    }

    public function destroyPerpustakaan($id)
    {
        // Menghapus data anggaran berdasarkan ID
        // Gunakan model untuk melakukan penghapusan
        $simpan = $this->anggaranModel->delete($id);

        // cek jika proses simpan gagal
        if (!$simpan) {
            // redirect ke halaman create
            session()->setFlashdata('pesan', 'Data Gagal dihapus!');
            return redirect()->to('/anggaran/index/perpustakaan');
        }
        // jika berhasil
        else {
            // redirect ke halaman index
            session()->setFlashdata('pesan', 'Data Berhasil dihapus!');
            return redirect()->to('/anggaran/index/perpustakaan');
        }
    }

    public function destroyKearsipan($id)
    {
        // Menghapus data anggaran berdasarkan ID
        // Gunakan model untuk melakukan penghapusan
        $simpan = $this->anggaranModel->delete($id);

        // cek jika proses simpan gagal
        if (!$simpan) {
            // redirect ke halaman create
            session()->setFlashdata('pesan', 'Data Gagal dihapus!');
            return redirect()->to('/anggaran/index/kearsipan');
        }
        // jika berhasil
        else {
            // redirect ke halaman index
            session()->setFlashdata('pesan', 'Data Berhasil dihapus!');
            return redirect()->to('/anggaran/index/kearsipan');
        }
    }
}
