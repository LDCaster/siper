<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Bab1lakipModel;
use App\Models\KaryawanModel;

class Bab1lakipController extends BaseController
{
    protected $bab1lakipModel;
    protected $karyawanModel;

    public function __construct()
    {
        $this->bab1lakipModel = new Bab1lakipModel();
        $this->karyawanModel = new KaryawanModel();
    }

    public function index()
    {
        $data = [
            'bab1lakips' => $this->bab1lakipModel->getBab1lakip(),
        
        ];
        // dd($data);

        return view('bab1lakip/index', $data);
    }
    

    public function create()
    {
        // Mengambil data Karyawan untuk digunakan dalam form create
        $karyawans = $this->karyawanModel->findAll();

        return view('bab1lakip/create', ['karyawans' => $karyawans]);
    }

    public function store()
    {
        // Validasi dan penyimpanan data Indikator Kinerja Urusan
        // Anda dapat menggunakan $this->request->getPost() untuk mengambil data dari form
        // Kemudian, gunakan model untuk menyimpan data sesuai kebutuhan

        // Contoh validasi
        $validationRules = [
            'id_karyawan' => 'required',
            
        ];

        if ($this->validate($validationRules)) {
            // Data valid, simpan ke database
            $data = [
                'id_karyawan' => $this->request->getPost('id_karyawan'),
                
            ];

            $this->bab1lakipModel->insert($data);

            return redirect()->to('/bab1lakip');
        } else {
            // Validasi gagal, tampilkan kembali form dengan pesan error
            return view('bab1lakip/create', [
                'karyawans' => $this->karyawanModel->findAll(),
                'validation' => $this->validator,
            ]);
        }
    }

    public function edit($id)
    {
        // Mengambil data Indikator Kinerja Urusan berdasarkan ID
        $bab1lakip = $this->bab1lakipModel->find($id);

        // Mengambil data Urusan untuk digunakan dalam form edit
        $karyawans = $this->karyawanModel->findAll();

        return view('bab1lakip/edit', ['bab1lakip' => $bab1lakip, 'karyawans' => $karyawans]);
    }

    public function update($id)
    {
        // Validasi dan pembaruan data Indikator Kinerja Urusan berdasarkan ID
        // Anda dapat menggunakan $this->request->getPost() untuk mengambil data dari form
        // Kemudian, gunakan model untuk memperbarui data sesuai kebutuhan

        // Contoh validasi
        $validationRules = [
            'id_karyawan' => 'required',
            
        ];

        if ($this->validate($validationRules)) {
            // Data valid, update data ke database
            $data = [
                'id_karyawan' => $this->request->getPost('id_karyawan'),
                
            ];

            $this->bab1lakipModel->update($id, $data);

            return redirect()->to('/bab1lakip');
        } else {
            // Validasi gagal, tampilkan kembali form dengan pesan error
            return view('bab1lakip/edit', [
                'bab1lakip' => $this->bab1lakipModel->find($id),
                'karyawans' => $this->karyawanModel->findAll(),
                'validation' => $this->validator,
            ]);
        }
    }

    public function destroy($id)
    {
        // Menghapus data Indikator Kinerja karyawan berdasarkan ID
        // Gunakan model untuk melakukan penghapusan
        $this->bab1lakipModel->delete($id);

        return redirect()->to('/bab1lakip');
    }
}
