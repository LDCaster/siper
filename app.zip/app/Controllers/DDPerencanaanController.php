<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DDPerencanaanModel;
use CodeIgniter\HTTP\Files\UploadedFile;


class DDPerencanaanController extends BaseController
{
    protected $DDPerencanaanModel;

    public function __construct()
    {
        $this->DDPerencanaanModel = new DDPerencanaanModel();
    }

    public function index()
    {
        $data['dd_perencanaan'] = $this->DDPerencanaanModel->getAllData();
        return view('perencanaan/datadukung/index', $data);
    }

    public function create()
    {
        return view('perencanaan/datadukung/create');
    }

    public function store()
    {
        $validationRules = [
            'nama_file' => 'required',
            'file' => 'uploaded[file]|ext_in[file,pdf]|max_size[file,20240]', // Maksimal 20MB
            'tahun' => 'required'
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->to('/ddperencanaan/create')->withInput()->with('validation', $this->validator);
        }

        $file = $this->request->getFile('file');

        // Pindahkan file yang diunggah ke folder yang diinginkan
        $newFileName = $file->getRandomName();
        $file->move(ROOTPATH . 'public/uploads/ddPerencanaan/', $newFileName);

        // Simpan data ke database
        $this->DDPerencanaanModel->save([
            'nama_file' => $this->request->getPost('nama_file'),
            'file' => $newFileName,
            'tahun' => $this->request->getPost('tahun')
        ]);

        return redirect()->to('/ddperencanaan')->with('success', 'Data Dukung berhasil ditambahkan.');
    }

    // Tambahkan metode untuk menampilkan pratinjau file PDF dan terapkan mpdf
    public function preview($id)
    {
        $data['dd_detail'] = $this->DDPerencanaanModel->find($id);
        return view('perencanaan/datadukung/preview', $data);
    }    


    public function download($id)
    {
        $data = $this->DDPerencanaanModel->find($id);
        return $this->response->download(ROOTPATH . 'public/uploads/ddPerencanaan/' . $data['file'], null);
    }

    public function delete($id)
    {
        $data = $this->DDPerencanaanModel->find($id);
        unlink(ROOTPATH . 'public/uploads/ddPerencanaan/' . $data['file']); // Hapus file dari folder uploads
        $this->DDPerencanaanModel->delete($id);

        return redirect()->to('/ddperencanaan')->with('success', 'Data Dukung berhasil dihapus.');
    }

}
