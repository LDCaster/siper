<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Bab3lakipModel;

class Bab3lakipController extends BaseController
{
    public function index()
    {
        $Bab3lakipModel = new Bab3lakipModel();
        $data['bab3lakips'] = $Bab3lakipModel->findAll();
        return view('bab3lakip/index', $data);
    }

    public function create()
    {
        return view('bab3lakip/create');
    }

    public function store()
    {
        $Bab3lakipModel = new Bab3lakipModel();
        $data = [
            'penyebab' => $this->request->getPost('penyebab'),
            'alternatif' => $this->request->getPost('alternatif'),
            'analisis_sumberdaya' => $this->request->getPost('analisis_sumberdaya'),
            'analisis_program_kegiatan' => $this->request->getPost('analisis_program_kegiatan'),
        ];
        $Bab3lakipModel->insert($data);

        return redirect()->to('/bab3lakip');
    }

    public function edit($id)
    {
        $Bab3lakipModel = new Bab3lakipModel();
        $data['bab3lakip'] = $Bab3lakipModel->find($id);
        return view('bab3lakip/edit', $data);
    }

    public function update($id)
    {
        $Bab3lakipModel = new Bab3lakipModel();
        $data = [
            'penyebab' => $this->request->getPost('penyebab'),
            'alternatif' => $this->request->getPost('alternatif'),
            'analisis_sumberdaya' => $this->request->getPost('analisis_sumberdaya'),
            'analisis_program_kegiatan' => $this->request->getPost('analisis_program_kegiatan'),
        ];
        $Bab3lakipModel->update($id, $data);

        return redirect()->to('/bab3lakip');
    }

    public function destroy($id)
    {
        $Bab3lakipModel = new Bab3lakipModel();
        $Bab3lakipModel->delete($id);

        return redirect()->to('/bab3lakip');
    }
}
