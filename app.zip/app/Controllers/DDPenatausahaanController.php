<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DDPenatausahaanModel;
use CodeIgniter\HTTP\Files\UploadedFile;


class DDPenatausahaanController extends BaseController
{
    protected $DDPenatausahaanModel;

    public function __construct()
    {
        $this->DDPenatausahaanModel = new DDPenatausahaanModel();
    }

    public function index()
    {
        $data['dd_penatausahaan'] = $this->DDPenatausahaanModel->getAllData();
        return view('datadukungpenatausahaan/index', $data);
    }

    public function create()
    {
        return view('datadukungpenatausahaan/create');
    }

    public function store()
    {
        $validationRules = [
            'nama_file' => 'required',
            'file' => 'uploaded[file]|ext_in[file,pdf]|max_size[file,20240]', // Maksimal 20MB
            'tahun' => 'required'
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->to('/ddpenatausahaan/create')->withInput()->with('validation', $this->validator);
        }

        $file = $this->request->getFile('file');

        // Pindahkan file yang diunggah ke folder yang diinginkan
        $newFileName = $file->getRandomName();
        $file->move(ROOTPATH . 'public/uploads/ddPenatausahaan/', $newFileName);

        // Simpan data ke database
        $this->DDPenatausahaanModel->save([
            'nama_file' => $this->request->getPost('nama_file'),
            'file' => $newFileName,
            'tahun' => $this->request->getPost('tahun')
        ]);

        return redirect()->to('/ddpenatausahaan')->with('success', 'Data Dukung berhasil ditambahkan.');
    }

    // Tambahkan metode untuk menampilkan pratinjau file PDF dan terapkan mpdf
    public function preview($id)
    {
        $data['dd_detail'] = $this->DDPenatausahaanModel->find($id);
        return view('datadukungpenatausahaan/preview', $data);
    }    


    public function download($id)
    {
        $data = $this->DDPenatausahaanModel->find($id);
        return $this->response->download(ROOTPATH . 'public/uploads/ddPenatausahaan/' . $data['file'], null);
    }

    public function destroy($id)
    {
        $data = $this->DDPenatausahaanModel->find($id);
        unlink(ROOTPATH . 'public/uploads/ddPenatausahaan/' . $data['file']); // Hapus file dari folder uploads
        $this->DDPenatausahaanModel->delete($id);

        return redirect()->to('/ddpenatausahaan')->with('success', 'Data Dukung berhasil dihapus.');
    }
}
