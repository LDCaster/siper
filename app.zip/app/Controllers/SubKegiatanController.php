<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\IndikatorKinerjaUrusanModel;
use App\Models\SubKegiatanModel;
use App\Models\UrusanModel;
use App\Models\ProgramModel;
use App\Models\KegiatanModel;

class SubKegiatanController extends BaseController
{
    protected $subkegiatanModel;
    protected $indikatorKinerjaUrusanModel;
    protected $urusanModel;
    protected $programModel;
    protected $kegiatanModel;

    public function __construct()
    {
        $this->subkegiatanModel = new SubKegiatanModel();
        $this->indikatorKinerjaUrusanModel = new IndikatorKinerjaUrusanModel();
        $this->urusanModel = new UrusanModel();
        $this->programModel = new ProgramModel();
        $this->kegiatanModel = new KegiatanModel();
    }

    public function index()
    {
        $subkegiatan = $this->subkegiatanModel->getSubkegiatan();

        $data = [
            'title' => 'Sub Kegiatan',
            'subkegiatan' => $subkegiatan,
        ];

        return view('subkegiatan/index', $data);
    }

    public function create()
    {
        $urusan = $this->urusanModel->findAll();
        $indikatorKinerjaUrusan = $this->indikatorKinerjaUrusanModel->findAll();
        $program = $this->programModel->findAll();
        $kegiatan = $this->kegiatanModel->findAll();

        $data = [
            'title' => 'Tambah Data Sub Kegiatan',
            'validation' => \Config\Services::validation(),
            'urusan' => $urusan,
            'indikatorKinerjaUrusan' => $indikatorKinerjaUrusan,
            'program' => $program,
            'kegiatan' => $kegiatan,
        ];

        return view('subkegiatan/create', $data);
    }

    public function store()
    {
        $validationRules = [
            'nama_subkegiatan' => 'required',
            'id_urusan' => 'required',
            'id_indikator_kinerja_urusan' => 'required',
            'id_program' => 'required',
            'id_kegiatan' => 'required',
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'nama_subkegiatan' => $this->request->getPost('nama_subkegiatan'),
            'id_urusan' => $this->request->getPost('id_urusan'),
            'id_indikator_kinerja_urusan' => $this->request->getPost('id_indikator_kinerja_urusan'),
            'id_program' => $this->request->getPost('id_program'),
            'id_kegiatan' => $this->request->getPost('id_kegiatan'),
        ];

        $simpan = $this->subkegiatanModel->insert($data);

        if (!$simpan) {
            session()->setFlashdata('pesan', 'Data Gagal ditambahkan!');
            return redirect()->to('sub-kegiatan/create');
        } else {
            session()->setFlashdata('pesan', 'Data Berhasil ditambahkan!');
            return redirect()->to('/sub-kegiatan');
        }
    }

    public function edit($id)
    {
        $subkegiatan = $this->subkegiatanModel->find($id);
        $urusan = $this->urusanModel->findAll();
        $indikatorKinerjaUrusan = $this->subkegiatanModel->getIndikatorKinerjaByUrusan($subkegiatan['id_urusan']);
        $program = $this->subkegiatanModel->getProgramByIndikator($subkegiatan['id_indikator_kinerja_urusan']);
        $kegiatan = $this->subkegiatanModel->getKegiatanByProgram($subkegiatan['id_program']);

        $data = [
            'title' => 'Edit Data Sub Kegiatan',
            'validation' => \Config\Services::validation(),
            'subkegiatan' => $subkegiatan,
            'urusan' => $urusan,
            'indikatorKinerjaUrusan' => $indikatorKinerjaUrusan,
            'program' => $program,
            'kegiatan' => $kegiatan,
        ];

        return view('subkegiatan/edit', $data);
    }

    public function update($id)
    {
        $validationRules = [
            'nama_subkegiatan' => 'required',
            'id_urusan' => 'required',
            'id_indikator_kinerja_urusan' => 'required',
            'id_program' => 'required',
            'id_kegiatan' => 'required',
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'nama_subkegiatan' => $this->request->getPost('nama_subkegiatan'),
            'id_urusan' => $this->request->getPost('id_urusan'),
            'id_indikator_kinerja_urusan' => $this->request->getPost('id_indikator_kinerja_urusan'),
            'id_program' => $this->request->getPost('id_program'),
            'id_kegiatan' => $this->request->getPost('id_kegiatan'),
        ];

        $simpan = $this->subkegiatanModel->update($id, $data);

        if (!$simpan) {
            session()->setFlashdata('pesan', 'Data Gagal diubah!');
            return redirect()->to('/sub-kegiatan/edit/' . $id);
        } else {
            session()->setFlashdata('pesan', 'Data Berhasil diubah!');
            return redirect()->to('/sub-kegiatan');
        }
    }

    public function destroy($id)
    {
        $simpan = $this->subkegiatanModel->delete($id);

        if (!$simpan) {
            session()->setFlashdata('pesan', 'Data Gagal dihapus!');
            return redirect()->to('/sub-kegiatan');
        } else {
            session()->setFlashdata('pesan', 'Data Berhasil dihapus!');
            return redirect()->to('/sub-kegiatan');
        }
    }

    // Fungsi untuk mengambil data Indikator Kinerja Urusan berdasarkan Urusan yang dipilih (digunakan untuk dropdown berantai)
    public function getIndikatorKinerjaByUrusan($id_urusan)
    {
        $indikatorKinerja = $this->subkegiatanModel->getIndikatorKinerjaByUrusan($id_urusan);
        return $this->response->setJSON($indikatorKinerja);
    }

    // Fungsi untuk mengambil data Program berdasarkan Indikator Kinerja Urusan yang dipilih (digunakan untuk dropdown berantai)
    public function getProgramByIndikator($id_indikator_kinerja_urusan)
    {
        $programByIndikator = $this->subkegiatanModel->getProgramByIndikator($id_indikator_kinerja_urusan);
        return $this->response->setJSON($programByIndikator);
    }

    // Fungsi untuk mengambil data Kegiatan berdasarkan Program yang dipilih (digunakan untuk dropdown berantai)
    public function getKegiatanByProgram($id_program)
    {
        $kegiatanByProgram = $this->subkegiatanModel->getKegiatanByProgram($id_program);
        return $this->response->setJSON($kegiatanByProgram);
    }
}
