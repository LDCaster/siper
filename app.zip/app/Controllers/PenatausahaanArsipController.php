<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\PenatausahaanModel;
use App\Models\AnggaranModel;
use App\Models\KaryawanModel;

class PenatausahaanArsipController extends BaseController
{
    protected $penatausahaanModel;
    protected $karyawanModel;
    protected $anggaranModel;

    public function __construct()
    {
        $this->penatausahaanModel = new PenatausahaanModel();
        $this->karyawanModel = new KaryawanModel();
        $this->anggaranModel = new AnggaranModel();
    }

    public function index()
    {
        $data = [
            'penatausahaan_arsips' => $this->penatausahaanModel->getPenatausahaan(),
        
        ];
        // dd($data);

        return view('penatausahaan_arsip/index', $data);
    }
    

    public function create()
    {
        // Mengambil data Karyawan untuk digunakan dalam form create
        $karyawans = $this->karyawanModel->findAll();
        $anggarans = $this->anggaranModel->findAll();

        return view('penatausahaan_arsip/create', ['karyawans' => $karyawans, 'anggarans' => $anggarans]);
    }

    public function store()
    {
        // Validasi dan penyimpanan data Indikator Kinerja Urusan
        // Anda dapat menggunakan $this->request->getPost() untuk mengambil data dari form
        // Kemudian, gunakan model untuk menyimpan data sesuai kebutuhan

        // Contoh validasi
        $validationRules = [
            'id_anggaran' => 'required',
            'status' => 'required',
            'tanggal' => 'required',
            'karyawan_1' => 'required',
            'karyawan_2' => 'required',
            'kinerja_utama' => 'required',
            'indikator_kinerja' => 'required',
            'target' => 'required',
        ];

        if ($this->validate($validationRules)) {
            // Data valid, simpan ke database
            $data = [
                'id_anggaran' => $this->request->getPost('id_anggaran'),
                'status' => $this->request->getPost('status'),
                'tanggal' => $this->request->getPost('tanggal'),
                'karyawan_1' => $this->request->getPost('karyawan_1'),
                'karyawan_2' => $this->request->getPost('karyawan_2'),
                'kinerja_utama' => $this->request->getPost('kinerja_utama'),
                'indikator_kinerja' => $this->request->getPost('indikator_kinerja'),
                'target' => $this->request->getPost('target'),
            ];

            $this->penatausahaanModel->insert($data);

            return redirect()->to('/penatausahaan_arsip');
        } else {
            // Validasi gagal, tampilkan kembali form dengan pesan error
            return view('penatausahaan_arsip/create', [
                'karyawans' => $this->karyawanModel->findAll(),
                'anggarans' => $this->anggaranModel->findAll(),
                'validation' => $this->validator,
            ]);
        }
    }

    public function edit($id)
    {
        // Mengambil data Indikator Kinerja Urusan berdasarkan ID
        $penatausahaan_arsip = $this->penatausahaanModel->find($id);

        // Mengambil data Urusan untuk digunakan dalam form edit
        $karyawans = $this->karyawanModel->findAll();
        $anggarans = $this->anggaranModel->findAll();

        return view('penatausahaan_arsip/edit', ['penatausahaan_arsip' => $penatausahaan_arsip, 'karyawans' => $karyawans, 'anggarans' => $anggarans]);
    }

    public function update($id)
    {
        // Validasi dan pembaruan data Indikator Kinerja Urusan berdasarkan ID
        // Anda dapat menggunakan $this->request->getPost() untuk mengambil data dari form
        // Kemudian, gunakan model untuk memperbarui data sesuai kebutuhan

        // Contoh validasi
        $validationRules = [
            'id_anggaran' => 'required',
            'status' => 'required',
            'tanggal' => 'required',
            'karyawan_1' => 'required',
            'karyawan_2' => 'required',
            'kinerja_utama' => 'required',
            'indikator_kinerja' => 'required',
            'target' => 'required',
        ];

        if ($this->validate($validationRules)) {
            // Data valid, update data ke database
            $data = [
                'id_anggaran' => $this->request->getPost('id_anggaran'),
                'status' => $this->request->getPost('status'),
                'tanggal' => $this->request->getPost('tanggal'),
                'karyawan_1' => $this->request->getPost('karyawan_1'),
                'karyawan_2' => $this->request->getPost('karyawan_2'),
                'kinerja_utama' => $this->request->getPost('kinerja_utama'),
                'indikator_kinerja' => $this->request->getPost('indikator_kinerja'),
                'target' => $this->request->getPost('target'),
            ];

            $this->penatausahaanModel->update($id, $data);

            return redirect()->to('/penatausahaan_arsip');
        } else {
            // Validasi gagal, tampilkan kembali form dengan pesan error
            return view('penatausahaan_arsip/edit', [
                'penatausahaan_arsip' => $this->penatausahaanModel->find($id),
                'karyawans' => $this->karyawanModel->findAll(),
                'anggarans' => $this->anggaranModel->findAll(),
                'validation' => $this->validator,
            ]);
        }
    }

    public function destroy($id)
    {
        // Menghapus data Indikator Kinerja karyawan berdasarkan ID
        // Gunakan model untuk melakukan penghapusan
        $this->penatausahaanModel->delete($id);

        return redirect()->to('/penatausahaan_arsip');
    }
}
