<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Rute untuk menampilkan halaman login
$routes->get('/', 'AuthController::login', ['as' => 'login']);
$routes->get('login', 'AuthController::login', ['as' => 'login']);

 // Rute untuk proses login
 $routes->post('auth/processLogin', 'AuthController::processLogin', ['as' => 'auth/processLogin']);

 // Rute untuk logout
 $routes->get('logout', 'AuthController::logout', ['as' => 'logout']);

    $routes->get('/dashboard', 'Home::index');

    // karyawan
    $routes->get('/karyawan', 'KaryawanController::index', ['as' => 'karyawan/index']);
    $routes->get('/karyawan/create', 'KaryawanController::create', ['as' => 'karyawan/create']);
    $routes->post('/karyawan/store', 'KaryawanController::store', ['as' => 'karyawan/store']);
    $routes->get('/karyawan/show/(:num)', 'KaryawanController::show/$1', ['as' => 'karyawan/show']);
    $routes->get('/karyawan/edit/(:num)', 'KaryawanController::edit/$1', ['as' => 'karyawan/edit']);    
    $routes->post('/karyawan/update/(:num)', 'KaryawanController::update/$1', ['as' => 'karyawan/update']);
    $routes->get('/karyawan/delete/(:num)', 'KaryawanController::destroy/$1', ['as' => 'karyawan/delete']);

    // urusan
    $routes->get('/urusan', 'UrusanController::index', ['as' => 'urusan/index']);
    $routes->get('/urusan/create', 'UrusanController::create', ['as' => 'urusan/create']);
    $routes->post('/urusan/store', 'UrusanController::store', ['as' => 'urusan/store']);
    $routes->get('/urusan/edit/(:num)', 'UrusanController::edit/$1', ['as' => 'urusan/edit']);
    $routes->post('/urusan/update/(:num)', 'UrusanController::update/$1', ['as' => 'urusan/update']);
    $routes->get('/urusan/delete/(:num)', 'UrusanController::destroy/$1', ['as' => 'urusan/delete']);

    // indikator kinerja urusan
    $routes->get('/indikator-kinerja-urusan', 'IndikatorKinerjaUrusanController::index', ['as' => 'indikator-kinerja-urusan/index']);
    $routes->get('/indikator-kinerja-urusan/create', 'IndikatorKinerjaUrusanController::create', ['as' => 'indikator-kinerja-urusan/create']);
    $routes->post('/indikator-kinerja-urusan/store', 'IndikatorKinerjaUrusanController::store', ['as' => 'indikator-kinerja-urusan/store']);
    $routes->get('/indikator-kinerja-urusan/edit/(:num)', 'IndikatorKinerjaUrusanController::edit/$1', ['as' => 'indikator-kinerja-urusan/edit']);
    $routes->post('/indikator-kinerja-urusan/update/(:num)', 'IndikatorKinerjaUrusanController::update/$1', ['as' => 'indikator-kinerja-urusan/update']);
    $routes->get('/indikator-kinerja-urusan/delete/(:num)', 'IndikatorKinerjaUrusanController::destroy/$1', ['as' => 'indikator-kinerja-urusan/delete']);

    // Kegiatan
    $routes->get('/kegiatan', 'KegiatanController::index', ['as' => 'kegiatan/index']);
    $routes->get('/kegiatan/create', 'KegiatanController::create', ['as' => 'kegiatan/create']);
    $routes->post('/kegiatan/store', 'KegiatanController::store', ['as' => 'kegiatan/store']);
    $routes->get('/kegiatan/edit/(:num)', 'KegiatanController::edit/$1', ['as' => 'kegiatan/edit']);
    $routes->post('/kegiatan/update/(:num)', 'KegiatanController::update/$1', ['as' => 'kegiatan/update']);
    $routes->get('/kegiatan/delete/(:num)', 'KegiatanController::destroy/$1', ['as' => 'kegiatan/delete']);
    $routes->get('/kegiatan/getIndikatorKinerja/(:num)', 'KegiatanController::getIndikatorKinerja/$1');
    $routes->get('/kegiatan/getProgram/(:num)', 'KegiatanController::getProgram/$1');

    // Program
    $routes->get('/program', 'ProgramController::index', ['as' => 'program/index']);
    $routes->get('/program/create', 'ProgramController::create', ['as' => 'program/create']);
    $routes->post('/program/store', 'ProgramController::store', ['as' => 'program/store']);
    $routes->get('/program/edit/(:num)', 'ProgramController::edit/$1', ['as' => 'program/edit']);
    $routes->post('/program/update/(:num)', 'ProgramController::update/$1', ['as' => 'program/update']);
    $routes->get('/program/delete/(:num)', 'ProgramController::destroy/$1', ['as' => 'program/delete']);
    $routes->get('/program/getIndikatorKinerja/(:num)', 'ProgramController::getIndikatorKinerja/$1');

    // indikator sub kegiatan
    $routes->get('/indikator', 'IndikatorController::index', ['as' => 'indikator/index']);
    $routes->get('/indikator/create', 'IndikatorController::create', ['as' => 'indikator/create']);
    $routes->post('/indikator/store', 'IndikatorController::store', ['as' => 'indikator/store']);
    $routes->get('/indikator/edit/(:num)', 'IndikatorController::edit/$1', ['as' => 'indikator/edit']);
    $routes->post('/indikator/update/(:num)', 'IndikatorController::update/$1', ['as' => 'indikator/update']);
    $routes->get('/indikator/delete/(:num)', 'IndikatorController::destroy/$1', ['as' => 'indikator/delete']);
    $routes->get('/indikator/getIndikatorKinerjaByUrusan/(:num)', 'IndikatorController::getIndikatorKinerjaByUrusan/$1');
    $routes->get('/indikator/getProgramByIndikator/(:num)', 'IndikatorController::getProgramByIndikator/$1');
    $routes->get('/indikator/getKegiatanByProgram/(:num)', 'IndikatorController::getKegiatanByProgram/$1');
    $routes->get('/indikator/getSubkegiatanByKegiatan/(:num)', 'IndikatorController::getSubkegiatanByKegiatan/$1');

    // sub kegiatan
    $routes->get('/sub-kegiatan', 'SubKegiatanController::index', ['as' => 'sub-kegiatan/index']);
    $routes->get('/sub-kegiatan/create', 'SubKegiatanController::create', ['as' => 'sub-kegiatan/create']);
    $routes->post('/sub-kegiatan/store', 'SubKegiatanController::store', ['as' => 'sub-kegiatan/store']);
    $routes->get('/sub-kegiatan/edit/(:num)', 'SubKegiatanController::edit/$1', ['as' => 'sub-kegiatan/edit']);
    $routes->post('/sub-kegiatan/update/(:num)', 'SubKegiatanController::update/$1', ['as' => 'sub-kegiatan/update']);
    $routes->get('/sub-kegiatan/delete/(:num)', 'SubKegiatanController::destroy/$1', ['as' => 'sub-kegiatan/delete']);
    $routes->get('/sub-kegiatan/getIndikatorKinerjaByUrusan/(:num)', 'SubKegiatanController::getIndikatorKinerjaByUrusan/$1');
    $routes->get('/sub-kegiatan/getProgramByIndikator/(:num)', 'SubKegiatanController::getProgramByIndikator/$1');
    $routes->get('/sub-kegiatan/getKegiatanByProgram/(:num)', 'SubKegiatanController::getKegiatanByProgram/$1');

    // satuan
    $routes->get('/satuan', 'SatuanController::index', ['as' => 'satuan/index']);
    $routes->get('/satuan/create', 'SatuanController::create', ['as' => 'satuan/create']);
    $routes->post('/satuan/store', 'SatuanController::store', ['as' => 'satuan/store']);
    $routes->get('/satuan/edit/(:num)', 'SatuanController::edit/$1', ['as' => 'satuan/edit']);
    $routes->post('/satuan/update/(:num)', 'SatuanController::update/$1', ['as' => 'satuan/update']);
    $routes->get('/satuan/delete/(:num)', 'SatuanController::destroy/$1', ['as' => 'satuan/delete']);   
    $routes->get('/satuan/getIndikatorKinerjaByUrusan/(:num)', 'SatuanController::getIndikatorKinerjaByUrusan/$1');
    $routes->get('/satuan/getProgramByIndikator/(:num)', 'SatuanController::getProgramByIndikator/$1');
    $routes->get('/satuan/getKegiatanByProgram/(:num)', 'SatuanController::getKegiatanByProgram/$1');
    $routes->get('/satuan/getSubKegiatanByKegiatan/(:num)', 'SatuanController::getSubkegiatanByKegiatan/$1');
    $routes->get('/satuan/getIndikatorBySubKegiatan/(:num)', 'SatuanController::getIndikatorBySubkegiatan/$1');

    // data dukung penatausahaan
    $routes->get('ddpenatausahaan', 'DDPenatausahaanController::index', ['as' => 'ddpenatausahaan/index']);
    $routes->get('/ddpenatausahaan/create', 'DDPenatausahaanController::create', ['as' => 'ddpenatausahaan/create']);
    $routes->post('/ddpenatausahaan/store', 'DDPenatausahaanController::store', ['as' => 'ddpenatausahaan/store']);
    $routes->get('/ddpenatausahaan/edit/(:num)', 'DDPenatausahaanController::edit/$1', ['as' => 'ddpenatausahaan/edit']);
   $routes->get('ddpenatausahaan/preview/(:num)', 'DDPenatausahaanController::preview/$1', ['as' => 'ddpenatausahaan/preview']);
   $routes->get('ddpenatausahaan/download/(:num)', 'DDPenatausahaanController::download/$1', ['as' => 'ddpenatausahaan/download']);
    $routes->post('/ddpenatausahaan/update/(:num)', 'DDPenatausahaanController::update/$1', ['as' => 'ddpenatausahaan/update']);
    $routes->get('/ddpenatausahaan/delete/(:num)', 'DDPenatausahaanController::destroy/$1', ['as' => 'ddpenatausahaan/delete']);

    // user
    $routes->get('/user', 'UserController::index', ['as' => 'user/index']);
    $routes->get('/user/create', 'UserController::create', ['as' => 'user/create']);
    $routes->post('/user/store', 'UserController::store', ['as' => 'user/store']);
    $routes->get('/user/show/(:num)', 'UserController::show/$1', ['as' => 'user/show']);
    $routes->get('/user/edit/(:num)', 'UserController::edit/$1', ['as' => 'user/edit']);    
    $routes->post('/user/update/(:num)', 'UserController::update/$1', ['as' => 'user/update']);
    $routes->get('/user/delete/(:num)', 'UserController::destroy/$1', ['as' => 'user/delete']);

    // perencanaan
    $routes->get('/perencanaan/index/rakor', 'PerencanaanController::indexRakortekbang', ['as' => 'perencanaan/index/rakor']);
    $routes->get('/perencanaan/index/renja', 'PerencanaanController::indexRenja', ['as' => 'perencanaan/index/renja']);
    $routes->get('/perencanaan/create/rakor', 'PerencanaanController::createRakortekbang', ['as' => 'perencanaan/create/rakor']);  
    $routes->get('/perencanaan/create/renja', 'PerencanaanController::createRenja', ['as' => 'perencanaan/create/renja']);  
    $routes->post('/perencanaan/store', 'PerencanaanController::store', ['as' => 'perencanaan/store']);
    $routes->get('/perencanaan/edit/(:num)', 'PerencanaanController::edit/$1', ['as' => 'perencanaan/edit']);
    $routes->post('/perencanaan/update/(:num)', 'PerencanaanController::update/$1', ['as' => 'perencanaan/update']);
    $routes->delete('/perencanaan/deleteRakor/(:num)', 'PerencanaanController::destroyRakor/$1', ['as' => 'perencanaan/deleteRakor']);
    $routes->delete('/perencanaan/deleteRenja/(:num)', 'PerencanaanController::destroyRenja/$1', ['as' => 'perencanaan/deleteRenja']);
    $routes->get('/perencanaan/getIndikatorKinerjaByUrusan/(:num)', 'PerencanaanController::getIndikatorKinerjaByUrusan/$1');
    $routes->get('/perencanaan/getProgramByIndikatorKinerja/(:num)', 'PerencanaanController::getProgramByIndikatorKinerja/$1');
    $routes->get('/perencanaan/getKegiatanByProgram/(:num)', 'PerencanaanController::getKegiatanByProgram/$1');
    $routes->get('/perencanaan/getSubKegiatanByKegiatan/(:num)', 'PerencanaanController::getSubkegiatanByKegiatan/$1');
    $routes->get('/perencanaan/getIndikatorBySubKegiatan/(:num)', 'PerencanaanController::getIndikatorBySubkegiatan/$1');
    $routes->get('/perencanaan/getSatuanByIndikator/(:num)', 'PerencanaanController::getSatuanByIndikator/$1');
    $routes->get('cetakRakor', 'PerencanaanController::cetakRakortekbang');
    $routes->get('tampilanCetakRakor', 'PerencanaanController::cetakRakortekbangView');
    $routes->get('cetakRenja', 'PerencanaanController::cetakRenja');
    $routes->get('tampilanCetakRenja', 'PerencanaanController::cetakRenjaView');
    

    $routes->get('/kesinambungan', 'KesinambunganController::index', ['as' => 'kesinambungan']);

   //  penatausahaan
    $routes->get('/penatausahaan', 'PenatausahaanController::index', ['as' => 'penatausahaan/index']);
    $routes->get('/penatausahaan/create', 'PenatausahaanController::create', ['as' => 'penatausahaan/create']);
    $routes->post('/penatausahaan/store', 'PenatausahaanController::store', ['as' => 'penatausahaan/store']);
    $routes->get('/penatausahaan/show/(:num)', 'PenatausahaanController::show/$1', ['as' => 'penatausahaan/show']);
    $routes->get('/penatausahaan/edit/(:num)', 'PenatausahaanController::edit/$1', ['as' => 'penatausahaan/edit']);    
    $routes->post('/penatausahaan/update/(:num)', 'PenatausahaanController::update/$1', ['as' => 'penatausahaan/update']);
    $routes->get('/penatausahaan/delete/(:num)', 'PenatausahaanController::destroy/$1', ['as' => 'penatausahaan/delete']);
    
    // penatausahaan
    $routes->get('/penatausahaan_arsip', 'PenatausahaanArsipController::index', ['as' => 'penatausahaan_arsip/index']);
    $routes->get('/penatausahaan_arsip/create', 'PenatausahaanArsipController::create', ['as' => 'penatausahaan_arsip/create']);
    $routes->post('/penatausahaan_arsip/store', 'PenatausahaanArsipController::store', ['as' => 'penatausahaan_arsip/store']);
    $routes->get('/penatausahaan_arsip/show/(:num)', 'PenatausahaanArsipController::show/$1', ['as' => 'penatausahaan_arsip/show']);
    $routes->get('/penatausahaan_arsip/edit/(:num)', 'PenatausahaanArsipController::edit/$1', ['as' => 'penatausahaan_arsip/edit']);    
    $routes->post('/penatausahaan_arsip/update/(:num)', 'PenatausahaanArsipController::update/$1', ['as' => 'penatausahaan_arsip/update']);
    $routes->get('/penatausahaan_arsip/delete/(:num)', 'PenatausahaanArsipController::destroy/$1', ['as' => 'penatausahaan_arsip/delete']);

    // pelaporan
   $routes->get('/pelaporan', 'PelaporanController::index', ['as' => 'pelaporan/index']);
   $routes->get('/pelaporan/create', 'PelaporanController::create', ['as' => 'pelaporan/create']);
   $routes->post('/pelaporan/store', 'PelaporanController::store', ['as' => 'pelaporan/store']);
   $routes->get('/pelaporan/show/(:num)', 'PelaporanController::show/$1', ['as' => 'pelaporan/show']);
   $routes->get('/pelaporan/edit/(:num)', 'PelaporanController::edit/$1', ['as' => 'pelaporan/edit']);    
   $routes->post('/pelaporan/update/(:num)', 'PelaporanController::update/$1', ['as' => 'pelaporan/update']);
   $routes->get('/pelaporan/delete/(:num)', 'PelaporanController::destroy/$1', ['as' => 'pelaporan/delete']);

   //  data dukung perencanaan
   $routes->get('ddperencanaan', 'DDPerencanaanController::index', ['as' => 'ddperencanaan/index']);
   $routes->get('ddperencanaan/create', 'DDPerencanaanController::create', ['as' => 'ddperencanaan/create']);
   $routes->post('ddperencanaan/store', 'DDPerencanaanController::store', ['as' => 'ddperencanaan/store']);
   $routes->get('ddperencanaan/preview/(:num)', 'DDPerencanaanController::preview/$1', ['as' => 'ddperencanaan/preview']);
   $routes->get('ddperencanaan/download/(:num)', 'DDPerencanaanController::download/$1', ['as' => 'ddperencanaan/download']);
   $routes->get('ddperencanaan/delete/(:num)', 'DDPerencanaanController::delete/$1');

   // data dukung pelaporan
   $routes->get('ddpelaporan', 'DDPelaporanController::index', ['as' => 'ddpelaporan/index']);
   $routes->get('/ddpelaporan/create', 'DDPelaporanController::create', ['as' => 'ddpelaporan/create']);
   $routes->post('/ddpelaporan/store', 'DDPelaporanController::store', ['as' => 'ddpelaporan/store']);
   $routes->get('/ddpelaporan/edit/(:num)', 'DDPelaporanController::edit/$1', ['as' => 'ddpelaporan/edit']);
   $routes->post('/ddpelaporan/update/(:num)', 'DDPelaporanController::update/$1', ['as' => 'ddpelaporan/update']);
   $routes->get('ddpelaporan/preview/(:num)', 'DDPelaporanController::preview/$1', ['as' => 'ddpelaporan/preview']);
   $routes->get('ddpelaporan/download/(:num)', 'DDPelaporanController::download/$1', ['as' => 'ddpelaporan/download']);
   $routes->get('/ddpelaporan/delete/(:num)', 'DDPelaporanController::destroy/$1', ['as' => 'ddpelaporan/delete']);

   
    // anggaran
    $routes->get('/anggaran/index/perpustakaan', 'AnggaranController::indexPerpustakaan');
    $routes->get('/anggaran/create/perpustakaan', 'AnggaranController::createPerpustakaan');
    $routes->post('/anggaran/store/perpustakaan', 'AnggaranController::storePerpustakaan');
    $routes->add('/anggaran/edit/perpustakaan/(:num)', 'AnggaranController::editPerpustakaan/$1');
    $routes->add('/anggaran/update/perpustakaan/(:num)', 'AnggaranController::updatePerpustakaan/$1');
    $routes->get('/anggaran/delete/perpustakaan/(:num)', 'AnggaranController::destroyPerpustakaan/$1');
    $routes->get('/anggaran/previewCetakPerpus/(:num)', 'AnggaranController::previewCetakPerpus/$1');
    $routes->get('/anggaran/previewCetakPerpus', 'AnggaranController::previewCetakPerpus');

    $routes->get('/anggaran/index/kearsipan', 'AnggaranController::indexKearsipan');
    $routes->get('/anggaran/create/kearsipan', 'AnggaranController::createKearsipan');
    $routes->post('/anggaran/store/kearsipan', 'AnggaranController::storeKearsipan');
    $routes->get('/anggaran/edit/kearsipan/(:num)', 'AnggaranController::editKearsipan/$1');
    $routes->post('/anggaran/update/kearsipan/(:num)', 'AnggaranController::updateKearsipan/$1');
    $routes->get('/anggaran/delete/kearsipan/(:num)', 'AnggaranController::destroyKearsipan/$1');
   $routes->get('/anggaran/previewCetakArsip/(:num)', 'AnggaranController::previewCetakArsip/$1');
   $routes->get('/anggaran/previewCetakArsip', 'AnggaranController::previewCetakArsip');

    //  data dukung pengaggaran
   $routes->get('ddanggaran', 'DDAnggaranController::index', ['as' => 'ddAnggaran/index']);
   $routes->get('ddanggaran/create', 'DDAnggaranController::create', ['as' => 'ddAnggaran/create']);
   $routes->post('ddanggaran/store', 'DDAnggaranController::store', ['as' => 'ddAnggaran/store']);
   $routes->get('ddanggaran/preview/(:num)', 'DDAnggaranController::preview/$1', ['as' => 'ddAnggaran/preview']);
   $routes->get('ddanggaran/download/(:num)', 'DDAnggaranController::download/$1', ['as' => 'ddAnggaran/download']);
   $routes->get('ddanggaran/delete/(:num)', 'DDAnggaranController::destroy/$1', ['as' => 'ddAnggaran/destroy']);

   // bab1lakip
   $routes->get('/bab1lakip', 'Bab1lakipController::index', ['as' => 'bab1lakip/index']);
   $routes->get('/bab1lakip/create', 'Bab1lakipController::create', ['as' => 'bab1lakip/create']);
   $routes->post('/bab1lakip/store', 'Bab1lakipController::store', ['as' => 'bab1lakip/store']);
   $routes->get('/bab1lakip/show/(:num)', 'Bab1lakipController::show/$1', ['as' => 'bab1lakip/show']);
   $routes->get('/bab1lakip/edit/(:num)', 'Bab1lakipController::edit/$1', ['as' => 'bab1lakip/edit']);    
   $routes->post('/bab1lakip/update/(:num)', 'Bab1lakipController::update/$1', ['as' => 'bab1lakip/update']);
   $routes->get('/bab1lakip/delete/(:num)', 'Bab1lakipController::destroy/$1', ['as' => 'bab1lakip/delete']);


   // lampiran
   $routes->get('/lampiran', 'lampiranController::index', ['as' => 'lampiran/index']);
   $routes->get('/lampiran/create', 'lampiranController::create', ['as' => 'lampiran/create']);
   $routes->post('/lampiran/store', 'lampiranController::store', ['as' => 'lampiran/store']);
   $routes->get('/lampiran/show/(:num)', 'lampiranController::show/$1', ['as' => 'lampiran/show']);
   $routes->get('/lampiran/edit/(:num)', 'lampiranController::edit/$1', ['as' => 'lampiran/edit']);    
   $routes->post('/lampiran/update/(:num)', 'lampiranController::update/$1', ['as' => 'lampiran/update']);
   $routes->get('/lampiran/delete/(:num)', 'lampiranController::destroy/$1', ['as' => 'lampiran/delete']);
   $routes->get('lampiran/preview/(:num)', 'LampiranController::preview/$1', ['as' => 'lampiran/preview']);
   $routes->get('lampiran/download/(:num)', 'LampiranController::download/$1', ['as' => 'lampiran/download']);

   // babvlakip
   $routes->get('/babvlakip', 'BabvlakipController::index', ['as' => 'babvlakip/index']);
   $routes->get('/babvlakip/create', 'BabvlakipController::create', ['as' => 'babvlakip/create']);
   $routes->post('/babvlakip/store', 'BabvlakipController::store', ['as' => 'babvlakip/store']);
   $routes->get('/babvlakip/show/(:num)', 'BabvlakipController::show/$1', ['as' => 'babvlakip/show']);
   $routes->get('/babvlakip/edit/(:num)', 'BabvlakipController::edit/$1', ['as' => 'babvlakip/edit']);    
   $routes->post('/babvlakip/update/(:num)', 'BabvlakipController::update/$1', ['as' => 'babvlakip/update']);
   $routes->get('/babvlakip/delete/(:num)', 'BabvlakipController::destroy/$1', ['as' => 'babvlakip/delete']);

   // bab3lakip
   $routes->get('/bab3lakip', 'Bab3lakipController::index', ['as' => 'bab3lakip/index']);
   $routes->get('/bab3lakip/create', 'Bab3lakipController::create', ['as' => 'bab3lakip/create']);
   $routes->post('/bab3lakip/store', 'Bab3lakipController::store', ['as' => 'bab3lakip/store']);
   $routes->get('/bab3lakip/show/(:num)', 'Bab3lakipController::show/$1', ['as' => 'bab3lakip/show']);
   $routes->get('/bab3lakip/edit/(:num)', 'Bab3lakipController::edit/$1', ['as' => 'bab3lakip/edit']);    
   $routes->post('/bab3lakip/update/(:num)', 'Bab3lakipController::update/$1', ['as' => 'bab3lakip/update']);
   $routes->get('/bab3lakip/delete/(:num)', 'Bab3lakipController::destroy/$1', ['as' => 'bab3lakip/delete']);
